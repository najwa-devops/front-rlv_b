"use client"

import { useState, useEffect, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { AlertCircle, Upload, Clock, CheckCircle, Sparkles, Building2, List, Trash2 } from "lucide-react"
import { toast } from "sonner"
import { SidebarNav } from "@/components/sidebar-nav"
import { StatsCards } from "@/components/stats-cards"
import { InvoiceTable } from "@/components/invoice-table"
import { InvoiceFilters, type FilterValues } from "@/components/invoice-filters"
import { UploadPage } from "@/components/upload-page"
import { BreadcrumbNav } from "@/components/breadcrumb-nav"
import { OcrProcessingPage } from "@/components/ocr-processing-page"
import { PatternManagementPage } from "@/components/pattern-management-page"
import { useIsMobile } from "@/hooks/use-mobile"
import { type LocalInvoice, type LocalTemplate, DEFAULT_FIELDS, type BankStatementV2, type BankTransactionV2, DEFAULT_BANK_FIELDS } from "@/lib/types"
import { api } from "@/lib/api"
import { invoiceDtoToLocal } from "@/lib/utils"
import { TemplatesInvoicesPage } from "@/components/templates-invoices-page"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { UploadedFilesPage } from "@/components/uploaded-files-page"
import { ValidatedInvoicesPage } from "@/components/validated-invoices-page"
import { UploadBankPage } from "@/components/upload-bank-page"
import { UploadedBankFilesPage } from "@/components/uploaded-bank-files-page"
import { ValidatedBankStatementsPage } from "@/components/validated-bank-statements-page"
import { BankStatementTable } from "@/components/bank-statement-table"
import { OcrProcessingBankPage } from "@/components/ocr-processing-bank-page"
import { BankStatsCards } from "@/components/bank-stats-cards"
import { BankSettingsPage } from "@/components/bank-settings-page"
import type { BankStatementStats } from "@/lib/types"



const DEMO_INVOICES: LocalInvoice[] = [
  {
    id: 1,
    filename: "facture-evoleo-001.pdf",
    filePath: "/uploads/facture-evoleo-001.pdf",
    fileSize: 245760,
    fileUrl: "/invoice-pdf-document-evoleo.jpg",
    fields: DEFAULT_FIELDS.map((f, i) => ({
      ...f,
      value:
        i === 0 ? "FAC-2026-001"
          : i === 1 ? "EVOLEO SARL"
            : i === 2 ? "003501940000019"
              : i === 3 ? "08/01/2026"
                : i === 4 ? "1500.00"
                  : i === 5 ? "300.00"
                    : i === 6 ? "1800.00"
                      : "",
      detected: i < 5,
    })),
    createdAt: new Date("2026-01-08"),
  },
  {
    id: 2,
    filename: "facture-digital-world.jpg",
    filePath: "/uploads/facture-digital-world.jpg",
    fileSize: 1572864,
    fields: DEFAULT_FIELDS.map((f, i) => ({
      ...f,
      value:
        i === 0 ? "0125 11 / 2025"
          : i === 1 ? "DIGITAL WORLD PRINT"
            : i === 2 ? "002072081000018"
              : i === 3 ? "07/11/2025"
                : i === 4 ? "600.00"
                  : i === 5 ? "120.00"
                    : i === 6 ? "720.00"
                      : "",
      detected: true,
    })),
    status: "validated",
    createdAt: new Date("2026-01-07"),
  },
  {
    id: 3,
    filename: "facture-maroc-telecom.pdf",
    filePath: "/uploads/facture-maroc-telecom.pdf",
    fileSize: 524288,
    fileUrl: "/invoice-pdf-maroc-telecom.jpg",
    fields: [],
    status: "pending",
    createdAt: new Date("2026-01-06"),
  },
]

const DEMO_BANK_STATEMENTS: BankStatementV2[] = [
  {
    id: 1,
    filename: "releve-bank.pdf",
    originalName: "releve-bank.pdf",
    filePath: "/uploads/releve-bank.pdf",
    fileSize: 0,
    rib: "MA01234567890106156401000",
    bankName: "SOCIÉTÉ GÉNÉRALE",
    month: 1,
    year: 2011,
    openingBalance: 0,
    closingBalance: 0,
    totalCredit: 0,
    totalDebit: 0,
    transactionCount: 0,
    validTransactionCount: 0,
    errorTransactionCount: 0,
    overallConfidence: 0,
    continuityStatus: "NONE",
    isBalanceValid: false,
    isContinuityValid: false,
    status: "ERROR",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 2,
    filename: "nouveau-releve-compte.pdf",
    originalName: "nouveau-releve-compte.pdf",
    filePath: "/uploads/nouveau-releve-compte.pdf",
    fileSize: 0,
    rib: "MA763000801234000123456781",
    bankName: "SOCIÉTÉ GÉNÉRALE",
    month: 1,
    year: 2011,
    openingBalance: 0,
    closingBalance: 1631,
    totalCredit: 0,
    totalDebit: 0,
    transactionCount: 0,
    validTransactionCount: 0,
    errorTransactionCount: 0,
    overallConfidence: 0,
    continuityStatus: "NONE",
    isBalanceValid: false,
    isContinuityValid: false,
    status: "ERROR",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 3,
    filename: "R_B.JPG",
    originalName: "R_B.JPG",
    filePath: "/uploads/R_B.JPG",
    fileSize: 0,
    rib: "",
    bankName: "ATTIJARIWAFA BANK",
    month: 1,
    year: 2024,
    openingBalance: 0,
    closingBalance: 0,
    totalCredit: 0,
    totalDebit: 0,
    transactionCount: 0,
    validTransactionCount: 0,
    errorTransactionCount: 0,
    overallConfidence: 0,
    continuityStatus: "NONE",
    isBalanceValid: false,
    isContinuityValid: false,
    status: "ERROR",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 4,
    filename: "R_B.JPG",
    originalName: "R_B.JPG",
    filePath: "/uploads/R_B.JPG",
    fileSize: 0,
    rib: "",
    bankName: "ATTIJARIWAFA BANK",
    month: 1,
    year: 2024,
    openingBalance: 0,
    closingBalance: 0,
    totalCredit: 0,
    totalDebit: 0,
    transactionCount: 0,
    validTransactionCount: 0,
    errorTransactionCount: 0,
    overallConfidence: 0,
    continuityStatus: "NONE",
    isBalanceValid: false,
    isContinuityValid: false,
    status: "ERROR",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 5,
    filename: "R_B.JPG",
    originalName: "R_B.JPG",
    filePath: "/uploads/R_B.JPG",
    fileSize: 0,
    rib: "",
    bankName: "ATTIJARIWAFA BANK",
    month: 1,
    year: 2024,
    openingBalance: 0,
    closingBalance: 0,
    totalCredit: 0,
    totalDebit: 0,
    transactionCount: 0,
    validTransactionCount: 0,
    errorTransactionCount: 0,
    overallConfidence: 0,
    continuityStatus: "NONE",
    isBalanceValid: false,
    isContinuityValid: false,
    status: "ERROR",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 6,
    filename: "R_B.JPG",
    originalName: "R_B.JPG",
    filePath: "/uploads/R_B.JPG",
    fileSize: 0,
    rib: "",
    bankName: "ATTIJARIWAFA BANK",
    month: 1,
    year: 2024,
    openingBalance: 0,
    closingBalance: 0,
    totalCredit: 0,
    totalDebit: 0,
    transactionCount: 0,
    validTransactionCount: 0,
    errorTransactionCount: 0,
    overallConfidence: 0,
    continuityStatus: "NONE",
    isBalanceValid: false,
    isContinuityValid: false,
    status: "ERROR",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
]

export default function Home() {
  // TOUS LES HOOKS EN PREMIER (useState, useEffect, useMemo)
  const [currentPage, setCurrentPage] = useState("dashboard")
  const [invoices, setInvoices] = useState<LocalInvoice[]>([])
  const [templates, setTemplates] = useState<LocalTemplate[]>([])
  const [selectedInvoice, setSelectedInvoice] = useState<LocalInvoice | null>(null)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isDemoMode, setIsDemoMode] = useState(false)
  const [isAdmin] = useState(true)
  const isMobile = useIsMobile()
  const [recentlyUploadedIds, setRecentlyUploadedIds] = useState<number[]>([])

  // Bank statement state
  const [bankStatements, setBankStatements] = useState<BankStatementV2[]>([])
  const [selectedBankStatement, setSelectedBankStatement] = useState<BankStatementV2 | null>(null)
  const [recentlyUploadedBankIds, setRecentlyUploadedBankIds] = useState<number[]>([])
  const [filters, setFilters] = useState<FilterValues>({
    search: "",
    supplier: "",
    status: "",
    dateFrom: undefined,
    dateTo: undefined,
    amountMin: undefined,
    amountMax: undefined,
  })

  // Bank stats state
  const [bankStats, setBankStats] = useState<BankStatementStats | null>(null)

  useEffect(() => {
    loadInvoices()
    loadBankStatements()
  }, [])

  // 🆕 Polling pour les relevés en cours de traitement
  useEffect(() => {
    // On poll si un relevé est en attente ou en cours (version EN ou FR)
    const hasProcessing = bankStatements.some(s =>
      s.status === "PROCESSING" || s.status === "PENDING" ||
      s.status === "EN_COURS" || s.status === "EN_ATTENTE"
    )

    if (hasProcessing) {
      const interval = setInterval(() => {
        console.log("Polling bank statements status...")
        loadBankStatements()
      }, 2000) // Toutes les 2 secondes

      return () => clearInterval(interval)
    }
  }, [bankStatements])

  const suppliers = useMemo(() => {
    const supplierSet = new Set<string>()
    invoices.forEach((inv) => {
      const supplier = inv.fields.find((f) => f.key === "supplier")?.value
      if (supplier) supplierSet.add(String(supplier))
    })
    return Array.from(supplierSet)
  }, [invoices])

  const displayedInvoices = useMemo(() => {
    if (currentPage === "dashboard") {
      return invoices
    }

    if (currentPage === "invoices") {
      return invoices.filter(inv =>
        inv.status === "pending" ||
        inv.status === "processing" ||
        inv.status === "treated" ||
        inv.status === "ready_to_validate"
      )
    }

    if (currentPage === "uploaded-files") {
      // Fichiers uploadés récemment
      return invoices.filter(inv => recentlyUploadedIds.includes(inv.id))
    }

    if (currentPage === "validated") {
      // Factures validées
      return invoices.filter(inv => inv.status === "validated")
    }

    return invoices
  }, [invoices, currentPage, recentlyUploadedIds])

  const pendingCount = useMemo(() => {
    return invoices.filter(inv =>
      inv.status === "pending" ||
      inv.status === "processing" ||
      inv.status === "treated" ||
      inv.status === "ready_to_validate"
    ).length
  }, [invoices])

  //FONCTIONS (PAS DES HOOKS)
  const loadInvoices = async () => {
    try {
      setIsLoading(true)
      setIsDemoMode(false)
      const [dtos, templateDtos] = await Promise.all([
        api.getAllInvoices(),
        api.getAllTemplates()
      ])
      const localInvoices = dtos.map(invoiceDtoToLocal)
      localInvoices.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      setInvoices(localInvoices)
      setTemplates(templateDtos as any)
    } catch (err) {
      console.warn("API Invoices non disponible, mode démo activé")
      setIsDemoMode(true)
      const sortedDemo = [...DEMO_INVOICES].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      setInvoices(sortedDemo)
    } finally {
      setIsLoading(false)
    }
  }

  const loadBankStatements = async () => {
    try {
      // Charger d'abord la liste (critique pour l'UI)
      const statements = await api.getAllBankStatements({ limit: 1000 })
      setBankStatements(Array.isArray(statements) ? statements : [])

      // 🔄 Garder le relevé sélectionné à jour s'il est ouvert
      if (selectedBankStatement) {
        const updated = statements.find((s: BankStatementV2) => s.id === selectedBankStatement.id)
        if (updated) {
          setSelectedBankStatement(updated)
        }
      }

      // Les stats sont secondaires: ne pas casser la liste si cet appel échoue
      try {
        const stats = await api.getBankStatementStats()
        setBankStats(stats)
      } catch (statsErr) {
        console.warn("Impossible de charger les stats bancaires:", statsErr)
      }
    } catch (err) {
      console.error("Erreur chargement relevés bancaires:", err)
      // Ne PAS afficher les données de démo si l'API échoue, pour éviter la confusion
      setBankStatements([])
      setBankStats(null)
      // toast.error("Impossible de charger les relevés bancaires")
    }
  }

  const handleUpload = async (files: File[]) => {
    try {
      const uploadedIds: number[] = []

      for (const file of files) {
        if (isDemoMode) {
          const newId = Date.now() + Math.random()
          const newInvoice: LocalInvoice = {
            id: newId,
            filename: file.name,
            filePath: `/uploads/${file.name}`,
            fileSize: file.size,
            fileUrl: URL.createObjectURL(file),
            fields: DEFAULT_FIELDS.map((f) => ({ ...f })),
            status: "pending",
            createdAt: new Date(),
          }
          setInvoices((prev) => [newInvoice, ...prev])
          uploadedIds.push(newId)
        } else {
          const response = await api.uploadInvoice(file)
          uploadedIds.push(response.id)
          toast.success(`${file.name} uploadé`)
        }
      }

      await loadInvoices()

      // 🆕 Stocker les IDs et rediriger vers la nouvelle page
      setRecentlyUploadedIds(uploadedIds)
      setCurrentPage("uploaded-files")

      toast.success(`${files.length} fichier(s) uploadé(s)`)
    } catch (err) {
      console.error("Upload error:", err)
      toast.error("Erreur lors de l'upload")
    }
  }

  const handleProcessAllUploaded = async () => {
    const uploadedInvoices = invoices.filter(inv => recentlyUploadedIds.includes(inv.id))

    for (const invoice of uploadedInvoices) {
      try {
        await handleProcessInline(invoice)
      } catch (error) {
        console.error(`Erreur traitement ${invoice.filename}:`, error)
      }
    }

    // Rediriger vers "En Traitement"
    setCurrentPage("invoices")
    setRecentlyUploadedIds([])
  }

  const handleViewInvoice = (invoice: LocalInvoice, file?: File) => {
    console.log("Ouverture détails facture:", invoice.id, invoice.filename)
    setSelectedInvoice(invoice)
    setSelectedFile(file || null)
  }

  const handleProcessOcr = (invoice: LocalInvoice) => {
    console.log("Traitement OCR:", invoice.id)
    setSelectedInvoice(invoice)
    setSelectedFile(null)
  }

  const handleProcessInline = async (invoice: LocalInvoice) => {
    try {
      setInvoices((prev) =>
        prev.map((inv) =>
          inv.id === invoice.id ? { ...inv, status: "processing", isProcessing: true } : inv
        )
      )

      toast.loading("Traitement OCR en cours...", { id: `process-${invoice.id}` })

      const result = await api.processInvoice(invoice.id)
      const updatedInvoice = invoiceDtoToLocal(result)

      setInvoices((prev) =>
        prev.map((inv) =>
          inv.id === invoice.id
            ? {
              ...updatedInvoice,
              status: "pending", // ← RESTER EN ATTENTE
              isProcessing: false
            }
            : inv
        )
      )

      if (updatedInvoice.templateId) {
        toast.success(`✓ Traité via template`, { id: `process-${invoice.id}` })
      } else {
        toast.success(`✓ OCR terminé - Vérifiez les données`, { id: `process-${invoice.id}` })
      }
    } catch (err) {
      console.error("Erreur traitement:", err)
      setInvoices((prev) =>
        prev.map((inv) =>
          inv.id === invoice.id ? { ...inv, status: "error", isProcessing: false } : inv
        )
      )
      const errorMessage = err instanceof Error ? err.message : "Erreur inconnue"
      toast.error(`Erreur: ${errorMessage}`, { id: `process-${invoice.id}` })
    }
  }

  const handleDeleteInvoice = async (invoiceId: number) => {
    if (isDemoMode) {
      setInvoices((prev) => prev.filter((inv) => inv.id !== invoiceId))
      toast.success("Facture supprimée")
      return
    }

    try {
      await api.deleteInvoice(invoiceId)
      setInvoices((prev) => prev.filter((inv) => inv.id !== invoiceId))
      toast.success("Facture supprimée")
    } catch (err) {
      toast.error("Erreur lors de la suppression")
    }
  }

  const handleBackFromOcr = () => {
    console.log("Retour depuis OCR")
    setSelectedInvoice(null)
    setSelectedFile(null)
  }

  const handleInvoiceSaved = async (updatedInvoice: LocalInvoice) => {
    if (isDemoMode) {
      //  Mode démo : mise à jour locale
      setInvoices((prev) =>
        prev.map((inv) =>
          inv.id === updatedInvoice.id ? updatedInvoice : inv
        )
      )

      //  Message personnalisé selon le statut
      if (updatedInvoice.status === "validated") {
        toast.success("✓ Facture validée - Visible dans Factures Validées")
      } else {
        toast.success("✓ Modifications enregistrées")
      }

      setSelectedInvoice(null)
      setSelectedFile(null)
      return
    }

    //  Mode API : recharger les factures
    await loadInvoices()

    if (updatedInvoice.status === "validated") {
      toast.success("✓ Facture validée - Visible dans Factures Validées")
    } else {
      toast.success("✓ Modifications enregistrées")
    }

    setSelectedInvoice(null)
    setSelectedFile(null)
  }

  const handleExport = (format: "csv" | "excel" | "pdf") => {
    toast.info(`Export ${format.toUpperCase()} sera disponible prochainement`)
  }

  const handleNavigate = (page: string) => {
    if (page === "patterns") {
      // Redirect to the standalone patterns page
      window.location.href = "/patterns"
      return
    }
    console.log("Navigation vers:", page)
    setCurrentPage(page)
    setSelectedInvoice(null)
    setSelectedFile(null)
    setSelectedBankStatement(null)
  }

  const handleUpdateTemplate = async (templateId: number, data: { templateName: string; supplierType: string }) => {
    try {
      if (isDemoMode) {
        toast.success("Mode démo: Template mis à jour localement")
        return
      }
      await api.patchTemplate(templateId, data)
      await loadInvoices()
    } catch (error) {
      console.error("Erreur mise à jour:", error)
      toast.error("Erreur lors de la mise à jour du template")
    }
  }

  const handleDeleteTemplate = async (templateId: number) => {
    try {
      await api.deleteTemplate(templateId)
      await loadInvoices()
      toast.success("Template supprimé")
    } catch (error) {
      toast.error("Erreur suppression template")
    }
  }

  // Bank statement handlers
  const handleBankUpload = async (files: File[], bankType?: string) => {
    const uploadedIds: number[] = []
    const failed: Array<{ file: string; reason: string }> = []
    const effectiveBankType = bankType || localStorage.getItem("default_bank_processing") || "AUTO"

    // Get allowed banks from settings
    let allowedBanks: string[] = []
    const savedBanks = localStorage.getItem("selected_banks_processing")
    if (savedBanks) {
      try {
        allowedBanks = JSON.parse(savedBanks)
      } catch (e) {
        console.error("Error parsing saved banks", e)
      }
    }

    for (const file of files) {
      try {
        // Toujours appeler l'API réelle pour les relevés bancaires.
        // Le mode démo factures ne doit pas bloquer le flux banking.
        const response = await api.uploadBankStatement(file, effectiveBankType, allowedBanks)
        uploadedIds.push(response.id)
      } catch (err) {
        const reason = err instanceof Error ? err.message : "Erreur inconnue"
        failed.push({ file: file.name, reason })
        console.error(`Upload failed for ${file.name}:`, err)
      }
    }

    await loadBankStatements()
    setRecentlyUploadedBankIds(uploadedIds)
    setCurrentPage("bank-list")

    if (uploadedIds.length > 0) {
      toast.success(`${uploadedIds.length}/${files.length} relevé(s) uploadé(s)`)
    }
    if (failed.length > 0) {
      toast.error(
        failed.length === 1
          ? `Échec upload ${failed[0].file}: ${failed[0].reason}`
          : `${failed.length} upload(s) en échec`
      )
    }
  }

  const handleProcessAllUploadedBank = async () => {
    const uploadedStatements = bankStatements.filter(stmt => recentlyUploadedBankIds.includes(stmt.id))

    for (const statement of uploadedStatements) {
      try {
        await handleProcessBankInline(statement)
      } catch (error) {
        console.error(`Erreur traitement ${statement.filename}:`, error)
      }
    }

    setCurrentPage("bank-list")
    setRecentlyUploadedBankIds([])
  }

  const handleProcessBankInline = async (statement: BankStatementV2) => {
    try {
      setBankStatements((prev) =>
        prev.map((stmt) =>
          stmt.id === statement.id ? { ...stmt, status: "PROCESSING" } : stmt
        )
      )

      toast.loading("Traitement OCR en cours...", { id: `process-bank-${statement.id}` })

      const result = await api.processBankStatement(statement.id)

      setBankStatements((prev) =>
        prev.map((stmt) =>
          stmt.id === statement.id ? result : stmt
        )
      )

      toast.success(`✓ OCR terminé - Vérifiez les données`, { id: `process-bank-${statement.id}` })
    } catch (err) {
      console.error("Erreur traitement:", err)
      setBankStatements((prev) =>
        prev.map((stmt) =>
          stmt.id === statement.id ? { ...stmt, status: "ERROR", isProcessing: false } : stmt
        )
      )
      const errorMessage = err instanceof Error ? err.message : "Erreur inconnue"
      toast.error(`Erreur: ${errorMessage}`, { id: `process-bank-${statement.id}` })
    }
  }

  const handleViewBankStatement = async (statement: BankStatementV2) => {
    try {
      toast.loading("Chargement des détails...", { id: "loading-bank-details" })
      const detailedStatement = await api.getBankStatementById(statement.id)
      setSelectedBankStatement(detailedStatement)
      setCurrentPage("ocr-processing-bank")
      toast.dismiss("loading-bank-details")
    } catch (error) {
      console.error("Erreur chargement détails relevé:", error)
      toast.error("Impossible de charger les détails du relevé", { id: "loading-bank-details" })
    }
  }

  const handleDeleteBankStatement = async (statementId: number) => {
    try {
      await api.deleteBankStatement(statementId)
      setBankStatements((prev) => prev.filter((stmt) => stmt.id !== statementId))
      toast.success("Relevé bancaire supprimé")
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Erreur inconnue"
      toast.error(`Erreur: ${errorMessage}`)
    }
  }

  const handleDeleteAllBankStatements = async () => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer TOUS les relevés bancaires ? Cette action est irréversible.")) {
      return
    }
    try {
      await api.deleteAllBankStatements()
      setBankStatements([])
      toast.success("Tous les relevés ont été supprimés")
      // Update stats
      const stats = await api.getBankStatementStats()
      setBankStats(stats)
    } catch (err) {
      console.error("Delete all error:", err)
      toast.error("Erreur lors de la suppression de tous les relevés")
    }
  }

  const handleBankStatementSaved = async (updatedStatement: BankStatementV2) => {
    // We already updated types, but if we need to call API here:
    // This function is likely called from the detail page saving
    await loadBankStatements()
    setSelectedBankStatement(null)
  }

  const handleValidateBankStatement = async (statementId: number) => {
    try {
      toast.loading("Validation du relevé...", { id: `validate-bank-${statementId}` })
      await api.validateBankStatement(statementId)
      await loadBankStatements()
      toast.success("✓ Relevé validé - Les écritures sont prêtes", { id: `validate-bank-${statementId}` })
    } catch (err) {
      console.error("Erreur validation:", err)
      const errorMessage = err instanceof Error ? err.message : "Erreur inconnue"
      toast.error(`Erreur: ${errorMessage}`, { id: `validate-bank-${statementId}` })
    }
  }

  const handleReprocessBankStatement = async (statement: BankStatementV2) => {
    try {
      setBankStatements((prev) =>
        prev.map((stmt) =>
          stmt.id === statement.id ? { ...stmt, status: "PROCESSING" } : stmt
        )
      )

      toast.loading("Reprocessage OCR en cours...", { id: `reprocess-bank-${statement.id}` })

      // Get allowed banks from settings (matching handleBankUpload logic)
      let allowedBanks: string[] = []
      const savedBanks = localStorage.getItem("selected_banks_processing")
      console.log("[REPROCESS] localStorage(selected_banks_processing):", savedBanks)
      if (savedBanks) {
        try {
          allowedBanks = JSON.parse(savedBanks)
          console.log("[REPROCESS] Parsed allowedBanks:", allowedBanks)
        } catch (e) {
          console.error("Error parsing saved banks", e)
        }
      }

      await api.processBankStatement(statement.id, allowedBanks)
      await loadBankStatements()

      toast.success(`✓ Reprocessage lancé pour ${statement.filename}`, { id: `reprocess-bank-${statement.id}` })
    } catch (err) {
      console.error("Erreur reprocessage:", err)
      await loadBankStatements() // Reload to get certain state
      const errorMessage = err instanceof Error ? err.message : "Erreur inconnue"
      toast.error(`Erreur: ${errorMessage}`, { id: `reprocess-bank-${statement.id}` })
    }
  }

  const applyFilters = (invoicesList: LocalInvoice[]) => {
    return invoicesList.filter((invoice) => {
      if (filters.search) {
        const searchLower = filters.search.toLowerCase()
        const matchesFilename = invoice.filename.toLowerCase().includes(searchLower)
        const matchesNumber = String(invoice.fields.find((f) => f.key === "invoiceNumber")?.value || "")
          .toLowerCase()
          .includes(searchLower)
        const matchesSupplier = String(invoice.fields.find((f) => f.key === "supplier")?.value || "")
          .toLowerCase()
          .includes(searchLower)
        if (!matchesFilename && !matchesNumber && !matchesSupplier) return false
      }

      if (filters.supplier && filters.supplier !== "all") {
        const supplier = invoice.fields.find((f) => f.key === "supplier")?.value
        if (supplier !== filters.supplier) return false
      }

      if (filters.status && filters.status !== "all") {
        if (invoice.status !== filters.status) return false
      }

      if (filters.dateFrom && invoice.createdAt < filters.dateFrom) return false
      if (filters.dateTo && invoice.createdAt > filters.dateTo) return false

      if (filters.amountMin !== undefined || filters.amountMax !== undefined) {
        const ttc = Number.parseFloat(String(invoice.fields.find((f) => f.key === "amountTTC")?.value || "0"))
        if (filters.amountMin !== undefined && ttc < filters.amountMin) return false
        if (filters.amountMax !== undefined && ttc > filters.amountMax) return false
      }

      return true
    })
  }

  const getBreadcrumbItems = () => {
    switch (currentPage) {
      case "dashboard":
        return [{ label: "Tableau de bord" }]
      case "upload":
        return [{ label: "Tableau de bord", onClick: () => setCurrentPage("dashboard") }, { label: "Uploader" }]
      case "invoices":
        return [
          { label: "Tableau de bord", onClick: () => setCurrentPage("dashboard") },
          { label: "Factures en attente" },
        ]
      case "patterns":
        return [{ label: "Tableau de bord", onClick: () => setCurrentPage("dashboard") }, { label: "Patterns" }]
      case "upload-bank":
        return [{ label: "Tableau de bord", onClick: () => setCurrentPage("dashboard") }, { label: "Uploader relevé" }]
      case "bank-list":
        return [{ label: "Tableau de bord", onClick: () => setCurrentPage("dashboard") }, { label: "Relevés bancaires" }]
      case "bank-validated":
        return [{ label: "Tableau de bord", onClick: () => setCurrentPage("dashboard") }, { label: "Relevés validés" }]
      case "uploaded-bank-files":
        return [{ label: "Tableau de bord", onClick: () => setCurrentPage("dashboard") }, { label: "En cours" }]
      case "bank-settings":
        return [{ label: "Tableau de bord", onClick: () => setCurrentPage("dashboard") }, { label: "Configuration" }]
      default:
        return [{ label: "Tableau de bord" }]
    }
  }

  const getPageTitle = () => {
    switch (currentPage) {
      case "dashboard": return "Tableau de bord"
      case "upload": return "Uploader des factures"
      case "invoices": return "Factures en attente"
      case "patterns": return "Gestion des patterns"

      case "upload-bank": return "Uploader relevé bancaire"
      case "bank-list": return "Liste des relevés bancaires"
      case "bank-validated": return "Relevés bancaires validés"
      case "bank-settings": return "Configuration Bancaire"

      default: return "FactureOCR"
    }
  }

  const renderPlaceholder = (title: string) => (
    <div className="flex flex-col items-center justify-center py-20 bg-card/10 rounded-2xl border border-dashed border-border/50 backdrop-blur-sm">
      <div className="h-20 w-20 rounded-3xl bg-primary/20 flex items-center justify-center mb-6 shadow-inner">
        <Sparkles className="h-10 w-10 text-primary" />
      </div>
      <h3 className="text-2xl font-bold mb-3 tracking-tight">{title}</h3>
      <p className="text-muted-foreground text-center max-w-sm leading-relaxed">
        Cette fonctionnalité est en cours de développement. Elle sera disponible prochainement pour automatiser vos relevés bancaires.
      </p>
      <Button variant="outline" className="mt-8 gap-2" onClick={() => setCurrentPage("dashboard")}>
        Retour au tableau de bord
      </Button>
    </div>
  )

  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center py-20">
          <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center animate-pulse">
            <Clock className="h-8 w-8 text-primary" />
          </div>
          <p className="mt-4 text-muted-foreground">Chargement...</p>
        </div>
      )
    }

    switch (currentPage) {
      case "dashboard":
        return (
          <div className="space-y-6">
            {/* Afficher les stats de TOUTES les factures */}
            <StatsCards invoices={invoices} />

            {pendingCount > 0 && (
              <Card className="border-amber-500/50 bg-amber-500/10">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <AlertCircle className="h-5 w-5 text-amber-500" />
                    <div>
                      <p className="font-medium text-amber-700 dark:text-amber-300">
                        {pendingCount} facture{pendingCount > 1 ? "s" : ""} en attente
                      </p>
                      <Button
                        variant="link"
                        className="h-auto p-0 text-amber-700 dark:text-amber-300"
                        onClick={() => setCurrentPage("invoices")}
                      >
                        Voir les factures →
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <InvoiceFilters
              filters={filters}
              onFiltersChange={setFilters}
              suppliers={suppliers}
              onExport={handleExport}
            />

            {/* Afficher TOUTES les factures dans le dashboard */}
            <InvoiceTable
              invoices={applyFilters(invoices)}
              onView={handleViewInvoice}
              onProcessOcr={handleProcessOcr}
              onProcessInline={handleProcessInline}
              onDelete={handleDeleteInvoice}
            />
          </div>
        )

      case "templates":
        return (
          <TemplatesInvoicesPage
            invoices={invoices}
            templates={templates as any}
            onView={handleViewInvoice}
            onDelete={handleDeleteInvoice}
            onUpdateTemplate={handleUpdateTemplate}
            onDeleteTemplate={handleDeleteTemplate}
          />
        )

      case "upload":
        return <UploadPage onUpload={handleUpload} onViewInvoice={handleViewInvoice} isDemoMode={isDemoMode} />

      case "invoices":
        return (
          <div className="space-y-6">
            <Card className="border-border/50 bg-card/50">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-500/10">
                    <Clock className="h-6 w-6 text-amber-500" />
                  </div>
                  <div>
                    <CardTitle className="text-2xl">Factures En Attente</CardTitle>
                    <CardDescription>
                      {displayedInvoices.length} facture{displayedInvoices.length > 1 ? "s" : ""} à traiter
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
            </Card>

            <InvoiceFilters
              filters={filters}
              onFiltersChange={setFilters}
              suppliers={suppliers}
              onExport={handleExport}
            />

            <InvoiceTable
              invoices={applyFilters(displayedInvoices)}
              onView={handleViewInvoice}
              onProcessOcr={handleProcessOcr}
              onProcessInline={handleProcessInline}
              onDelete={handleDeleteInvoice}
            />

            {displayedInvoices.length === 0 && (
              <Card className="border-border/50">
                <CardContent className="pt-16 pb-16 text-center">
                  <CheckCircle className="h-10 w-10 text-emerald-500 mx-auto" />
                  <h3 className="mt-6 text-lg font-medium">Aucune facture en attente</h3>
                  <Button className="mt-6 gap-2" onClick={() => setCurrentPage("upload")}>
                    <Upload className="h-4 w-4" />
                    Uploader
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        )

      case "uploaded-files":
        return (
          <UploadedFilesPage
            invoices={displayedInvoices}
            onProcessAll={handleProcessAllUploaded}
            onProcessSingle={handleProcessInline}
            onView={handleViewInvoice}
            onNavigateToDashboard={() => setCurrentPage("dashboard")}
          />
        )

      case "validated": // NOUVELLE PAGE
        return (
          <ValidatedInvoicesPage
            invoices={invoices.filter(inv => inv.status === "validated")} // ← Uniquement validées
            filters={filters}
            onFiltersChange={setFilters}
            suppliers={suppliers}
            onView={handleViewInvoice}
            onDelete={handleDeleteInvoice}
            onExport={handleExport}
          />
        )

      case "patterns":
        return <PatternManagementPage />



      case "upload-bank":
        return <UploadBankPage onUpload={handleBankUpload} onViewBankStatement={handleViewBankStatement} isDemoMode={isDemoMode} />

      case "uploaded-bank-files":
        return (
          <UploadedBankFilesPage
            statements={bankStatements.filter(stmt => recentlyUploadedBankIds.includes(stmt.id))}
            onProcessAll={handleProcessAllUploadedBank}
            onProcessSingle={handleProcessBankInline}
            onView={handleViewBankStatement}
            onNavigateToDashboard={() => setCurrentPage("dashboard")}
          />
        )

      case "bank-list":
        return (
          <div className="space-y-6">
            <Card className="border-border/50 bg-card/50">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                    <Building2 className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-2xl">Liste des Relevés Bancaires</CardTitle>
                    <CardDescription>
                      {bankStatements.length} relevé{bankStatements.length > 1 ? "s" : ""} géré{bankStatements.length > 1 ? "s" : ""}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="flex justify-end pb-4 pr-6 pt-0">
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={handleDeleteAllBankStatements}
                  disabled={bankStatements.length === 0}
                  className="gap-2"
                >
                  <Trash2 className="h-4 w-4" />
                  Tout supprimer
                </Button>
              </CardContent>
            </Card>

            <BankStatsCards stats={bankStats} />

            <BankStatementTable
              statements={bankStatements.filter(stmt => stmt.status !== "VALIDATED" && stmt.status !== "VALIDE")}
              onView={handleViewBankStatement}
              onDelete={handleDeleteBankStatement}
              onValidate={handleValidateBankStatement}
              onReprocess={handleReprocessBankStatement}
              onSave={handleBankStatementSaved}
            />
          </div>
        )

      case "bank-validated":
        return (
          <div className="space-y-6">
            <BankStatsCards stats={bankStats} />
            <ValidatedBankStatementsPage
              statements={bankStatements.filter(stmt => stmt.status === "VALIDATED" || stmt.status === "VALIDE")}
              filters={filters}
              onFiltersChange={setFilters}
              suppliers={suppliers}
              onView={handleViewBankStatement}
              onDelete={handleDeleteBankStatement}
              onExport={handleExport}
            />
          </div>
        )

      case "bank-settings":
        return <BankSettingsPage />

      default:
        return null
    }
  }
  // RENDER CONDITIONNEL APRÈS TOUS LES HOOKS
  if (selectedInvoice) {
    console.log("Affichage OcrProcessingPage pour:", selectedInvoice.id)
    return (
      <div className="flex h-screen bg-background">
        {!isMobile && (
          <SidebarNav
            currentPage={currentPage}
            onNavigate={handleNavigate}
            isAdmin={isAdmin}
            pendingCount={pendingCount}
          />
        )}
        <main className="flex-1 overflow-auto">
          <OcrProcessingPage
            invoice={selectedInvoice}
            file={selectedFile}
            templates={templates}
            onBack={handleBackFromOcr}
            onSave={handleInvoiceSaved}
            isDemoMode={isDemoMode}
          />
        </main>
      </div>
    )
  }

  if (selectedBankStatement) {
    console.log("Affichage OcrProcessingBankPage pour:", selectedBankStatement.id)
    return (
      <div className="flex h-screen bg-background">
        {!isMobile && (
          <SidebarNav
            currentPage={currentPage}
            onNavigate={handleNavigate}
            isAdmin={isAdmin}
            pendingCount={pendingCount}
          />
        )}
        <main className="flex-1 overflow-auto">
          <OcrProcessingBankPage
            statement={selectedBankStatement}
            file={null} // Le composant gère la récupération via statement.fileUrl si file est null
            onBack={() => {
              setSelectedBankStatement(null)
              setCurrentPage("bank-list")
            }}
            onSave={handleBankStatementSaved}
          />
        </main>
      </div>
    )
  }

  // RENDER NORMAL
  return (
    <div className="flex h-screen bg-background">
      <SidebarNav currentPage={currentPage} onNavigate={handleNavigate} isAdmin={isAdmin} pendingCount={pendingCount} />

      <main className="flex-1 overflow-auto">
        <div className={`container mx-auto px-6 py-6 ${isMobile ? "pt-20" : ""}`}>
          {!isMobile && <BreadcrumbNav items={getBreadcrumbItems()} />}

          <div className="mb-8">
            <h1 className="text-3xl font-bold tracking-tight">{getPageTitle()}</h1>
          </div>

          {renderContent()}
        </div>
      </main>

    </div>
  )
}
