import {
  InvoiceCreateResponseDto,
  InvoiceDto as BackendInvoiceDto,
  InvoiceDto,
  DynamicTemplateDto,
  DynamicExtractionResponse,
  CreateDynamicTemplateRequest,
  SearchCriteria,
  FieldPattern,
  LearningSnapshot,
  CreateSnapshotRequest,
  CreateTemplateFromInvoiceRequest,
  CreateTemplateFromInvoiceResponse,
  UpdateDynamicTemplateRequest,
  Tier,
  DetectedFieldPattern,
  PatternStatistics,
  BankStatementV2,
  BankTransactionV2,
  BankStatementStats,
  FullValidationResponse,
  BankOption
} from "./types"

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8089"

type ApiEnvelope<T> = {
  success: boolean
  data: T
  error?: string
  code?: string
  details?: unknown
  timestamp?: string
}

export type DynamicInvoiceBulkItemResult = {
  invoiceId: number
  success: boolean
  status?: "VERIFY" | "READY_TO_TREAT" | "READY_TO_VALIDATE" | "VALIDATED" | "REJECTED"
  code?: string
  error?: string
  details?: unknown
}

export type DynamicInvoiceBulkResponse = {
  total: number
  successCount: number
  failedCount: number
  results: DynamicInvoiceBulkItemResult[]
}

export type AccountingConfigDto = {
  id: number
  journal: string
  designation: string
  banque: string
  compteComptable: string
  rib: string
}

export type UpsertAccountingConfigRequest = Omit<AccountingConfigDto, "id">

async function apiFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const headers = new Headers(init?.headers)

  if (typeof window !== "undefined") {
    const token = localStorage.getItem("token")
    if (token && !headers.has("Authorization")) {
      headers.set("Authorization", `Bearer ${token}`)
    }
  }

  const response = await fetch(input, { ...init, headers })

  if (!response.ok) return response

  const contentType = response.headers.get("content-type") || ""
  if (!contentType.includes("application/json")) return response

  try {
    const body = await response.clone().json() as ApiEnvelope<unknown> | unknown
    if (body && typeof body === "object" && "success" in (body as Record<string, unknown>) && "data" in (body as Record<string, unknown>)) {
      const envelope = body as ApiEnvelope<unknown>
      if (envelope.success) {
        return new Response(JSON.stringify(envelope.data), {
          status: response.status,
          statusText: response.statusText,
          headers: { "Content-Type": "application/json" },
        })
      }
      return new Response(JSON.stringify(envelope), {
        status: response.status >= 400 ? response.status : 400,
        statusText: "Business Error",
        headers: { "Content-Type": "application/json" },
      })
    }
  } catch {
    return response
  }

  return response
}
// ============================================
// HELPERS
// ============================================

export function normalizeStatus(status: any): string {
  if (!status) return "pending"
  const s = String(status).toLowerCase()
  if (s === "processed" || s === "treated") return "treated"
  if (s === "ready_to_validate" || s === "ready_to_validate") return "ready_to_validate"
  if (s === "validated") return "validated"
  if (s === "error") return "error"
  if (s === "processing") return "processing"
  return "pending"
}

export async function parseApiError(response: Response): Promise<string> {
  try {
    const contentType = response.headers.get("content-type") || ""
    if (!contentType.includes("application/json")) {
      const text = (await response.text()).trim()
      return text || response.statusText || `HTTP ${response.status}`
    }

    const errorData: any = await response.json()
    if (!errorData || Object.keys(errorData).length === 0) {
      return response.statusText || `HTTP ${response.status}`
    }

    // Retourner un message détaillé si disponible
    if (errorData.error && (errorData.receivedType || errorData.receivedName)) {
      return `${errorData.error} (Type: ${errorData.receivedType}, Name: ${errorData.receivedName})`
    }
    return errorData.message || errorData.error || response.statusText || `HTTP ${response.status}`
  } catch {
    return response.statusText
  }
}

export function getFileUrl(filePath: string): string {
  if (!filePath) return ""
  const filename = filePath.split(/[/\\]/).pop() || "file"
  return `${API_BASE_URL}/api/dynamic-invoices/files/${encodeURIComponent(filename)}`
}

export function getInvoicePdfUrl(filePath: string): string {
  return getFileUrl(filePath)
}

// ============================================
// DYNAMIC INVOICES API
// ============================================

export async function uploadInvoice(file: File): Promise<BackendInvoiceDto> {
  const formData = new FormData()
  formData.append("file", file)

  const response = await fetch(`${API_BASE_URL}/api/dynamic-invoices/upload`, {
    method: "POST",
    body: formData,
  })

  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function processInvoice(id: number): Promise<BackendInvoiceDto> {
  const response = await fetch(`${API_BASE_URL}/api/dynamic-invoices/${id}/process`, {
    method: "POST",
    headers: { "Accept": "application/json" }
  })

  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.invoice || data
}

export async function getInvoiceById(id: number): Promise<BackendInvoiceDto> {
  const response = await fetch(`${API_BASE_URL}/api/dynamic-invoices/${id}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function validateInvoice(id: number, userId?: string): Promise<any> {
  const url = userId
    ? `${API_BASE_URL}/api/dynamic-invoices/${id}/validate?userId=${encodeURIComponent(userId)}`
    : `${API_BASE_URL}/api/dynamic-invoices/${id}/validate`

  const response = await fetch(url, { method: "POST" })
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function updateInvoiceFields(id: number, fields: Record<string, any>): Promise<InvoiceDto> {
  const url = `${API_BASE_URL}/api/dynamic-invoices/${id}/fields`
  const body = JSON.stringify(fields)
  console.log(`[API] PUT ${url}`, fields)

  const response = await fetch(url, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body,
  })

  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.invoice || data
}

export async function getAllInvoices(status?: string, templateId?: number, limit?: number): Promise<InvoiceDto[]> {
  let url = `${API_BASE_URL}/api/dynamic-invoices`
  const params = new URLSearchParams()
  if (status) params.append("status", status)
  if (templateId) params.append("templateId", String(templateId))
  if (limit) params.append("limit", String(limit))

  if (params.toString()) {
    url += `?${params.toString()}`
  }

  const response = await fetch(url)
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.invoices || data || []
}

export async function deleteInvoice(id: number): Promise<void> {
  const response = await fetch(`${API_BASE_URL}/api/dynamic-invoices/${id}`, { method: "DELETE" })
  if (!response.ok) throw new Error(await parseApiError(response))
}

export async function getInvoiceStats(): Promise<any> {
  const response = await fetch(`${API_BASE_URL}/api/dynamic-invoices/stats`)
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

// ============================================
// DYNAMIC TEMPLATES API
// ============================================

export async function getAllTemplates(): Promise<DynamicTemplateDto[]> {
  const response = await fetch(`${API_BASE_URL}/api/dynamic-templates`)
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function getTemplateById(id: number): Promise<DynamicTemplateDto> {
  const response = await fetch(`${API_BASE_URL}/api/dynamic-templates/${id}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function createDynamicTemplate(request: CreateDynamicTemplateRequest): Promise<DynamicTemplateDto> {
  const url = `${API_BASE_URL}/api/dynamic-templates`
  const body = JSON.stringify(request)
  console.log(`[API] POST ${url}`, request)

  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body,
  })

  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function updateTemplate(id: number, request: CreateDynamicTemplateRequest): Promise<DynamicTemplateDto> {
  const response = await fetch(`${API_BASE_URL}/api/dynamic-templates/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request),
  })

  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function patchTemplate(id: number, request: UpdateDynamicTemplateRequest): Promise<DynamicTemplateDto> {
  const url = `${API_BASE_URL}/api/dynamic-templates/${id}`
  console.log(`[API] PATCH ${url}`, request)
  const response = await fetch(url, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request),
  })

  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function deactivateTemplate(id: number): Promise<void> {
  const response = await fetch(`${API_BASE_URL}/api/dynamic-templates/${id}`, { method: "DELETE" })
  if (!response.ok) throw new Error(await parseApiError(response))
}

export async function searchTemplates(name: string): Promise<DynamicTemplateDto[]> {
  const response = await fetch(`${API_BASE_URL}/api/dynamic-templates/search?name=${encodeURIComponent(name)}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function getTemplatesBySupplierType(supplierType: string): Promise<DynamicTemplateDto[]> {
  const response = await fetch(`${API_BASE_URL}/api/dynamic-templates/by-supplier-type/${encodeURIComponent(supplierType)}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function getReliableTemplates(): Promise<DynamicTemplateDto[]> {
  const response = await fetch(`${API_BASE_URL}/api/dynamic-templates/reliable`)
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function getTemplatesBySupplier(supplier: string): Promise<any> {
  const response = await fetch(`${API_BASE_URL}/api/dynamic-templates/by-supplier?supplier=${encodeURIComponent(supplier)}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

// ============================================
// EXTRACTION API
// ============================================

export async function extractWithTemplate(invoiceId: number, templateId?: number): Promise<DynamicExtractionResponse> {
  let url = `${API_BASE_URL}/api/dynamic-templates/extract/${invoiceId}`
  if (templateId) {
    url += `?templateId=${templateId}`
  }

  const response = await fetch(url, { method: "POST" })
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function extractFromFile(file: File, templateId?: number): Promise<DynamicExtractionResponse> {
  const formData = new FormData()
  formData.append("file", file)

  let url = `${API_BASE_URL}/api/dynamic-templates/extract-file`
  if (templateId) {
    url += `?templateId=${templateId}`
  }

  const response = await fetch(url, {
    method: "POST",
    body: formData,
  })

  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function testTemplate(templateId: number, ocrText: string): Promise<any> {
  const response = await fetch(`${API_BASE_URL}/api/dynamic-templates/${templateId}/test`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ocrText }),
  })

  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function detectTemplate(ocrText: string): Promise<any> {
  const response = await fetch(`${API_BASE_URL}/api/dynamic-templates/detect`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ocrText }),
  })

  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

// ============================================
// PATTERN MANAGEMENT API
// ============================================

/**
 * Maps backend FieldLearningDto to frontend DetectedFieldPattern
 */
function mapBackendPatternToFrontend(dto: any): DetectedFieldPattern {
  return {
    patternId: dto.id,
    invoiceId: dto.invoiceId,
    invoiceNumber: dto.invoiceId?.toString(), // Backend doesn't return invoice number directly
    fieldName: dto.fieldName,
    fieldLabel: dto.fieldName, // Will be mapped to label in UI
    patternText: dto.detectedPattern || "",
    fieldValue: dto.fieldValue,
    position: dto.valuePosition ? {
      x: dto.valuePosition.x || 0,
      y: dto.valuePosition.y || 0,
      width: dto.valuePosition.width || 0,
      height: dto.valuePosition.height || 0,
    } : undefined,
    status: dto.status, // PENDING, APPROVED, REJECTED
    detectedAt: dto.createdAt,
    approvedAt: dto.approvedAt,
    approvedBy: dto.approvedBy,
  }
}

export async function getAllPatterns(status?: string): Promise<DetectedFieldPattern[]> {
  let url = `${API_BASE_URL}/api/v2/learning/pending`

  const response = await fetch(url)
  if (!response.ok) throw new Error(await parseApiError(response))

  const data = await response.json()
  const patterns = data.map(mapBackendPatternToFrontend)

  if (status && status !== "all") {
    return patterns.filter((p: DetectedFieldPattern) => p.status.toLowerCase() === status.toLowerCase())
  }

  return patterns
}

export async function getPatternById(id: number): Promise<DetectedFieldPattern> {
  const patterns = await getAllPatterns()
  const pattern = patterns.find(p => p.patternId === id)
  if (!pattern) throw new Error("Pattern not found")
  return pattern
}

export async function approvePattern(id: number, approvedBy: string = "admin"): Promise<DetectedFieldPattern> {
  const response = await fetch(`${API_BASE_URL}/api/v2/learning/${id}/approve?approvedBy=${encodeURIComponent(approvedBy)}`, {
    method: "PUT",
  })

  if (!response.ok) throw new Error(await parseApiError(response))

  const data = await response.json()
  return mapBackendPatternToFrontend(data.pattern)
}

export async function rejectPattern(id: number, reason: string = "Rejected by user", rejectedBy: string = "admin"): Promise<DetectedFieldPattern> {
  const response = await fetch(
    `${API_BASE_URL}/api/v2/learning/${id}/reject?rejectedBy=${encodeURIComponent(rejectedBy)}&reason=${encodeURIComponent(reason)}`,
    {
      method: "PUT",
    }
  )

  if (!response.ok) throw new Error(await parseApiError(response))

  const data = await response.json()
  return mapBackendPatternToFrontend(data.pattern)
}

export async function getPatternStatistics(): Promise<PatternStatistics> {
  const response = await fetch(`${API_BASE_URL}/api/v2/learning/stats`)
  if (!response.ok) throw new Error(await parseApiError(response))

  const stats = await response.json()

  return {
    totalPatterns: stats.totalPatterns || 0,
    pendingPatterns: stats.pendingPatterns || 0,
    approvedPatterns: stats.approvedPatterns || 0,
    rejectedPatterns: stats.rejectedPatterns || 0,
    approvalRate: stats.approvalRate || 0,
    patternsByField: stats.patternsByField || {},
  }
}

export async function updateInvoiceFieldsWithPatterns(
  invoiceId: number,
  fieldsData: Record<string, any>,
  fieldPatterns?: Record<string, string>,
  patternPositions?: Record<string, any>,
  valuePositions?: Record<string, any>
): Promise<any> {
  const url = `${API_BASE_URL}/api/v2/invoices/${invoiceId}/fields-with-patterns`

  const payload = {
    fieldsData,
    fieldPatterns: fieldPatterns || {},
    patternPositions: patternPositions || {},
    valuePositions: valuePositions || {},
    detectionMethod: "USER_SELECTION",
  }

  console.log(`[API] PUT ${url}`, payload)

  const response = await fetch(url, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  })

  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

// ============================================
// BANKING API V2
// ============================================

// --- BankStatementController ---
export async function getAllTiers(activeOnly: boolean = true): Promise<Tier[]> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/tiers?activeOnly=${activeOnly}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.tiers || []
}

export async function getTierById(id: number): Promise<Tier> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/tiers/${id}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.tier
}

export async function getTierByTierNumber(tierNumber: string): Promise<Tier | null> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/tiers/by-tier-number/${tierNumber}`)
  if (response.status === 404) return null
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.tier
}

export async function getTierByIce(ice: string): Promise<Tier | null> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/tiers/by-ice/${ice}`)
  if (response.status === 404) return null
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.tier
}

export async function getTierByIfNumber(ifNumber: string): Promise<Tier | null> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/tiers/by-if-number/${ifNumber}`)
  if (response.status === 404) return null
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.tier
}

export async function searchTiers(query: string): Promise<Tier[]> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/tiers/search?query=${encodeURIComponent(query)}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.tiers || []
}

export async function createTier(request: CreateTierRequest): Promise<Tier> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/tiers`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request),
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.tier
}

export async function updateTier(id: number, request: UpdateTierRequest): Promise<Tier> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/tiers/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request),
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.tier
}

export async function deactivateTier(id: number): Promise<void> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/tiers/${id}`, { method: "DELETE" })
  if (!response.ok) throw new Error(await parseApiError(response))
}

export async function activateTier(id: number): Promise<void> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/tiers/${id}/activate`, { method: "PATCH" })
  if (!response.ok) throw new Error(await parseApiError(response))
}

// ============================================
// ACCOUNTING: ACCOUNTS
// ============================================

export async function getAccounts(activeOnly: boolean = true): Promise<Account[]> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/accounts?activeOnly=${activeOnly}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.accounts || []
}

export async function getAccountById(id: number): Promise<Account> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/accounts/${id}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.account
}

export async function getAccountByCode(code: string): Promise<Account | null> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/accounts/by-code/${code}`)
  if (response.status === 404) return null
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.account
}

export async function searchAccounts(query: string): Promise<Account[]> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/accounts/search?query=${encodeURIComponent(query)}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.accounts || []
}

export async function getAccountsByClasse(classe: number): Promise<Account[]> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/accounts/by-classe/${classe}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.accounts || []
}

export async function getChargeAccounts(): Promise<Account[]> {
  const accounts = await getAccounts(true)
  return accounts.filter(a => a.isChargeAccount || a.classe === 6 || a.code.startsWith("6"))
}

export async function getTvaAccounts(): Promise<Account[]> {
  const accounts = await getAccounts(true)
  return accounts.filter(a => a.isTvaAccount || a.classe === 3 || a.classe === 4 || a.code.startsWith("3455") || a.code.startsWith("4455"))
}

export async function getFournisseurAccounts(): Promise<Account[]> {
  const accounts = await getAccounts(true)
  return accounts.filter(a => a.isFournisseurAccount || a.code.startsWith("4411"))
}

export async function createAccount(request: CreateAccountRequest): Promise<Account> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/accounts`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request),
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.account
}

export async function updateAccount(id: number, request: UpdateAccountRequest): Promise<Account> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/accounts/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request),
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.account
}

export async function deactivateAccount(id: number): Promise<void> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/accounts/${id}`, { method: "DELETE" })
  if (!response.ok) throw new Error(await parseApiError(response))
}

export async function activateAccount(id: number): Promise<void> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/accounts/${id}/activate`, { method: "PATCH" })
  if (!response.ok) throw new Error(await parseApiError(response))
}

export async function importAccounts(requests: CreateAccountRequest[]): Promise<any> {
  const response = await apiFetch(`${API_BASE_URL}/api/accounting/accounts/import`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(requests),
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

// ============================================
// ACCOUNTING CONFIGS API
// ============================================

export async function getAccountingConfigs(): Promise<AccountingConfigDto[]> {
  const response = await apiFetch(`${API_BASE_URL}/api/v2/accounting-configs`)
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.configs || data || []
}

export async function createAccountingConfig(request: UpsertAccountingConfigRequest): Promise<AccountingConfigDto> {
  const response = await apiFetch(`${API_BASE_URL}/api/v2/accounting-configs`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request),
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function updateAccountingConfig(id: number, request: UpsertAccountingConfigRequest): Promise<AccountingConfigDto> {
  const response = await apiFetch(`${API_BASE_URL}/api/v2/accounting-configs/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request),
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function deleteAccountingConfig(id: number): Promise<void> {
  const response = await apiFetch(`${API_BASE_URL}/api/v2/accounting-configs/${id}`, {
    method: "DELETE",
  })
  if (!response.ok) throw new Error(await parseApiError(response))
}

export async function getAccountingConfigBanks(): Promise<string[]> {
  const response = await apiFetch(`${API_BASE_URL}/api/v2/accounting-configs/banks`)
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.banks || []
}

// ============================================
// BANK STATEMENTS API
// ============================================

export async function uploadBankStatement(file: File, bankType?: string, allowedBanks?: string[]): Promise<BankStatementV2> {
  const formData = new FormData()
  formData.append("file", file)
  if (bankType && bankType !== "AUTO") {
    formData.append("bankType", bankType)
  }
  if (allowedBanks && allowedBanks.length > 0) {
    allowedBanks.forEach(bank => formData.append("allowedBanks", bank))
  }

  const response = await fetch(`${API_BASE_URL}/api/v2/bank-statements/upload`, {
    method: "POST",
    body: formData,
  })

  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function processBankStatement(id: number, allowedBanks?: string[]): Promise<BankStatementV2> {
  const query = new URLSearchParams()
  if (allowedBanks && allowedBanks.length > 0) {
    // Standardize to comma-separated string for more reliable backend parsing
    query.append("allowedBanks", allowedBanks.join(","))
  }
  const url = query.toString() ? `${API_BASE_URL}/api/v2/bank-statements/${id}/process?${query.toString()}` : `${API_BASE_URL}/api/v2/bank-statements/${id}/process`

  console.log(`[API] Reprocessing bank statement ${id} with allowedBanks:`, allowedBanks)
  console.log(`[API] URL: ${url}`)

  const response = await fetch(url, {
    method: "POST",
  })

  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function getBankStatementById(id: number): Promise<BankStatementV2> {
  const response = await fetch(`${API_BASE_URL}/api/v2/bank-statements/${id}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function getAllBankStatements(params?: { status?: string; rib?: string; month?: number; year?: number; limit?: number }): Promise<BankStatementV2[]> {
  const query = new URLSearchParams()
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) query.append(key, String(value))
    })
  }

  // Add timestamp to force cache busting
  query.append("_t", String(Date.now()))

  const response = await fetch(`${API_BASE_URL}/api/v2/bank-statements?${query.toString()}`, {
    cache: 'no-store',
    headers: {
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    }
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.statements || data || []
}

export async function deleteBankStatement(id: number): Promise<void> {
  const response = await apiFetch(`${API_BASE_URL}/api/v2/bank-statements/${id}`, { method: "DELETE" })
  if (!response.ok) throw new Error(await parseApiError(response))
}

export async function deleteAllBankStatements(): Promise<void> {
  const response = await apiFetch(`${API_BASE_URL}/api/v2/bank-statements/all`, { method: "DELETE" })
  if (!response.ok) throw new Error(await parseApiError(response))
}

export async function validateBankStatement(id: number): Promise<BankStatementV2> {
  const response = await fetch(`${API_BASE_URL}/api/v2/bank-statements/${id}/validate`, {
    method: "POST",
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function validateFullBankStatement(id: number): Promise<FullValidationResponse> {
  const response = await apiFetch(`${API_BASE_URL}/api/v2/bank-statements/${id}/validate-full`, { method: "POST" })
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function updateBankStatementStatus(
  id: number,
  status: string,
  updatedBy?: string
): Promise<BankStatementV2> {
  const response = await apiFetch(`${API_BASE_URL}/api/v2/bank-statements/${id}/status`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status, updatedBy }),
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.statement || data
}

export async function getBankStatementStats(): Promise<BankStatementStats> {
  const response = await fetch(`${API_BASE_URL}/api/v2/bank-statements/stats?_t=${Date.now()}`, {
    cache: 'no-store',
    headers: {
      'Cache-Control': 'no-cache, no-store, must-revalidate'
    }
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function retryFailedBankStatementPages(id: number): Promise<any> {
  const response = await fetch(`${API_BASE_URL}/api/v2/bank-statements/${id}/retry-failed`, {
    method: "POST",
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function getContinuityCheck(): Promise<any> {
  const response = await fetch(`${API_BASE_URL}/api/v2/bank-statements/continuity-check`)
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function getBankOptions(): Promise<{ count: number; options: BankOption[] }> {
  const response = await fetch(`${API_BASE_URL}/api/v2/bank-statements/bank-options`)
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export function getBankStatementImageUrl(filename: string): string {
  return `${API_BASE_URL}/api/v2/bank-statements/files/${encodeURIComponent(filename)}`
}

// --- BankTransactionController ---

export async function getBankTransactionById(id: number): Promise<BankTransactionV2> {
  const response = await fetch(`${API_BASE_URL}/api/v2/bank-transactions/${id}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function getTransactionsByStatementId(sId: number): Promise<BankTransactionV2[]> {
  const response = await fetch(`${API_BASE_URL}/api/v2/bank-transactions/statement/${sId}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.transactions || data || []
}

export async function searchBankTransactions(params: Record<string, any>): Promise<BankTransactionV2[]> {
  const query = new URLSearchParams(params)
  const response = await fetch(`${API_BASE_URL}/api/v2/bank-transactions/search?${query.toString()}`)
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.transactions || data || []
}

export async function updateBankTransaction(id: number, updates: Partial<BankTransactionV2>): Promise<BankTransactionV2> {
  const response = await fetch(`${API_BASE_URL}/api/v2/bank-transactions/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(updates),
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function bulkUpdateBankTransactions(ids: number[], updates: Record<string, any>): Promise<any> {
  const response = await apiFetch(`${API_BASE_URL}/api/v2/bank-transactions/bulk-update`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ids, updates }),
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function createBankTransaction(
  payload: {
    statementId: number
    transactionIndex?: number
    dateOperation: string
    dateValeur?: string
    libelle: string
    compte?: string
    categorie?: string
    sens?: "DEBIT" | "CREDIT"
    debit?: number
    credit?: number
    isLinked?: boolean
  }
): Promise<BankTransactionV2> {
  const response = await apiFetch(`${API_BASE_URL}/api/v2/bank-transactions`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

// ============================================
// DOSSIERS API
// ============================================

export type BackendDossierDto = {
  id: number
  name: string
  status?: string
  comptableId?: number
  comptableEmail?: string
  fournisseurId?: number
  fournisseurEmail?: string
  createdAt?: string
  invoicesCount?: number
  bankStatementsCount?: number
  pendingInvoicesCount?: number
  validatedInvoicesCount?: number
}

export async function getDossiers(): Promise<BackendDossierDto[]> {
  const response = await apiFetch(`${API_BASE_URL}/api/dossiers`)
  if (!response.ok) throw new Error(await parseApiError(response))
  const data = await response.json()
  return data.dossiers || []
}

export async function createDossier(payload: { nom: string; fournisseurEmail: string; fournisseurPassword: string }): Promise<any> {
  const response = await apiFetch(`${API_BASE_URL}/api/dossiers`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function markTransactionValid(id: number): Promise<BankTransactionV2> {
  const response = await fetch(`${API_BASE_URL}/api/v2/bank-transactions/${id}/mark-valid`, {
    method: "POST",
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function markTransactionForReview(id: number, notes: string): Promise<BankTransactionV2> {
  const response = await fetch(`${API_BASE_URL}/api/v2/bank-transactions/${id}/mark-for-review`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ notes }),
  })
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function getTransactionStatsByCategory(statementId?: number): Promise<any> {
  const url = statementId
    ? `${API_BASE_URL}/api/v2/bank-transactions/stats/by-categorie?statementId=${statementId}`
    : `${API_BASE_URL}/api/v2/bank-transactions/stats/by-categorie`

  const response = await fetch(url)
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}

export async function getTransactionQualityStats(): Promise<any> {
  const response = await fetch(`${API_BASE_URL}/api/v2/bank-transactions/stats/need-review`)
  if (!response.ok) throw new Error(await parseApiError(response))
  return response.json()
}



// ============================================
// UNIFIED API OBJECT & ALIASES
// ============================================

export const api = {
  // Invoices
  uploadInvoice,
  processInvoice,
  getInvoiceById,
  validateInvoice,
  updateInvoiceFields,
  getAllInvoices,
  deleteInvoice,
  getInvoiceStats,

  // Templates
  getAllTemplates,
  getTemplateById,
  createDynamicTemplate,
  updateTemplate,
  patchTemplate,
  deactivateTemplate,
  searchTemplates,
  getTemplatesBySupplierType,
  getReliableTemplates,
  getTemplatesBySupplier,

  // Extraction
  extractWithTemplate,
  extractFromFile,
  testTemplate,
  detectTemplate,

  // Accounting
  // Accounting
  getAccounts,
  getAccountById,
  getAccountByCode,
  searchAccounts,
  getAccountsByClasse,
  createAccount,
  updateAccount,
  deactivateAccount,
  activateAccount,
  importAccounts,
  getChargeAccounts,
  getTvaAccounts,
  getFournisseurAccounts,

  getTiers: getAllTiers,
  getAllTiers,
  getTierById,
  getTierByTierNumber,
  getTierByIfNumber,
  getTierByIce,
  searchTiers,
  createTier,
  updateTier,
  deactivateTier,
  activateTier,
  getAccountingConfigs,
  createAccountingConfig,
  updateAccountingConfig,
  deleteAccountingConfig,
  getAccountingConfigBanks,

  // Bank Statements
  uploadBankStatement,
  processBankStatement,
  getAllBankStatements,
  getBankStatementById,
  validateBankStatement,
  updateBankStatementStatus,
  deleteBankStatement,
  deleteAllBankStatements,
  getBankStatementStats,
  retryFailedBankStatementPages,
  getBankOptions,
  getTransactionsByStatementId,
  updateBankTransaction,
  createBankTransaction,
  // Helpers
  getFileUrl,
  getInvoicePdfUrl,

  // Pattern Management
  getAllPatterns,
  getPatternById,
  approvePattern,
  rejectPattern,
  getPatternStatistics,
  updateInvoiceFieldsWithPatterns,

  // Banking V2
  uploadBankStatement,
  processBankStatement,
  getBankStatementById,
  getAllBankStatements,
  deleteBankStatement,
  deleteAllBankStatements,
  validateBankStatement,
  validateFullBankStatement,
  getBankStatementStats,
  getBankOptions,
  getContinuityCheck,
  getBankStatementImageUrl,
  getBankTransactionById,
  getTransactionsByStatementId,
  searchBankTransactions,
  updateBankTransaction,
  bulkUpdateBankTransactions,
  markTransactionValid,
  markTransactionForReview,
  getTransactionStatsByCategory,
  getTransactionQualityStats,
  retryFailedBankStatementPages,

  // Compatibility Aliases
  reprocessDynamic: processInvoice,
  updateDynamicFields: updateInvoiceFields,
  validateDynamicInvoice: validateInvoice,
  listDynamicInvoices: getAllInvoices,
  getAllDynamicTemplates: getAllTemplates,
  getDynamicTemplateById: getTemplateById,
  updateDynamicTemplate: updateTemplate,
  extractWithDynamicTemplate: extractWithTemplate,
  detectDynamicTemplate: detectTemplate,
  deactivateDynamicTemplate: deactivateTemplate,
  deleteTemplate: deactivateTemplate,

  // Tiers
  getAllTiers: async (): Promise<Tier[]> => {
    const response = await fetch(`${API_BASE_URL}/api/tiers`)
    if (!response.ok) {
      // Fallback mock if endpoint doesn't exist yet, to prevent blocking UI development
      console.warn("API /api/tiers not found, using empty list or mock")
      return []
    }
    return response.json()
  }
}
