"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Badge } from "@/components/ui/badge"
import { Sparkles, AlertCircle } from "lucide-react"
//import { createTemplate } from "@/lib/api"
import { createTemplateFromInvoice } from "@/lib/api"
import { toast } from "sonner" //  Import depuis 'sonner', pas depuis 'use-toast'
import type { LocalInvoice } from "@/lib/types"

interface TemplateSignatureDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  invoice: LocalInvoice
  ice?: string | null
  ifNumber?: string | null
  supplier?: string | null
  onSuccess?: () => void
}

export function TemplateSignatureDialog({
  open,
  onOpenChange,
  invoice,
  ice,
  ifNumber,
  supplier,
  onSuccess,
}: TemplateSignatureDialogProps) {
  //  TOUS LES HOOKS EN PREMIER (AVANT TOUT RETURN)
  const [selectedSignature, setSelectedSignature] = useState<"ice" | "if" | null>(null)
  const [isCreating, setIsCreating] = useState(false)

  const hasIce = ice && ice.trim() !== ""
  const hasIf = ifNumber && ifNumber.trim() !== ""

  //  useEffect APRÈS tous les useState
  useEffect(() => {
    if (hasIce && !selectedSignature) {
      setSelectedSignature("ice")
    } else if (hasIf && !selectedSignature) {
      setSelectedSignature("if")
    }
  }, [hasIce, hasIf, selectedSignature])

  //  Fonctions (pas des hooks)
  const handleCreate = async () => {
    if (!selectedSignature) {
      toast.error("Veuillez sélectionner une signature (ICE ou IF)")
      return
    }

    try {
      setIsCreating(true)

      const fieldsWithPosition = invoice.fields
        .filter(f => f.position !== undefined && f.position !== null)
        .map(f => ({
          fieldName: f.key,
          value: String(f.value || ""),
          position: {
            x: f.position!.x,
            y: f.position!.y,
            width: f.position!.width,
            height: f.position!.height,
          }
        }))

      if (fieldsWithPosition.length < 3) {
        toast.error(
          `Nombre de champs insuffisant\n\n` +
          `Trouvés: ${fieldsWithPosition.length}\n` +
          `Requis: minimum 3 champs avec positions`,
          { duration: 5000 }
        )
        setIsCreating(false)
        return
      }

      const payload = {
        invoiceId: invoice.id,
        signatureType: selectedSignature,
        ice: ice || undefined,
        ifNumber: ifNumber || undefined,
        supplier: supplier || undefined,
        fieldsWithPosition
      }

      console.log(" PAYLOAD CREATE TEMPLATE:", JSON.stringify(payload))

      const response = await createTemplateFromInvoice(payload)

      //  NOUVEAU: Template créé, status inchangé
      toast.success(
        ` Template créé avec succès\n\n` +
        `La facture reste au statut "${invoice.status}"\n` +
        `Vous pouvez la valider maintenant ou plus tard`,
        { duration: 6000 }
      )

      onOpenChange(false)

      if (onSuccess) {
        onSuccess()
      }

    } catch (error) {
      console.error(" Erreur création template:", error)

      const errorMessage = error instanceof Error ? error.message : "Erreur inconnue"

      if (errorMessage.includes("existe déjà")) {
        toast.error(" Un template existe déjà pour cette signature", { duration: 5000 })
      } else {
        toast.error(`Erreur: ${errorMessage}`)
      }
    } finally {
      setIsCreating(false)
    }
  }

  const handleCancel = () => {
    onOpenChange(false)
  }

  //  RETURN À LA FIN (APRÈS TOUS LES HOOKS)
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            Créer un template pour ce fournisseur ?
          </DialogTitle>
          <DialogDescription>
            Ce template permettra un traitement 70% plus rapide des prochaines factures de{" "}
            <span className="font-semibold text-foreground">{supplier || "ce fournisseur"}</span>.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="rounded-lg border border-primary/20 bg-primary/5 p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-primary mt-0.5" />
              <div className="flex-1 text-sm">
                <p className="font-medium text-foreground mb-1">Qu'est-ce qu'une signature ?</p>
                <p className="text-muted-foreground">
                  La signature (ICE ou IF) permet d'identifier automatiquement ce fournisseur pour les prochaines
                  factures.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <Label className="text-base font-semibold">Signature à utiliser:</Label>

            <RadioGroup
              value={selectedSignature || ""}
              onValueChange={(value) => setSelectedSignature(value as "ice" | "if")}
              className="space-y-3"
            >
              {hasIce && (
                <div
                  className={`flex items-center space-x-3 rounded-lg border-2 p-4 transition-all cursor-pointer ${selectedSignature === "ice"
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-primary/50"
                    }`}
                  onClick={() => setSelectedSignature("ice")}
                >
                  <RadioGroupItem value="ice" id="ice" />
                  <div className="flex-1">
                    <Label htmlFor="ice" className="cursor-pointer flex items-center gap-2">
                      <span className="font-medium">ICE (Identifiant Commun de l'Entreprise)</span>
                      {selectedSignature === "ice" && <Badge className="bg-primary">Sélectionné</Badge>}
                    </Label>
                    <p className="text-sm text-muted-foreground mt-1 font-mono">{ice}</p>
                  </div>
                </div>
              )}

              {hasIf && selectedSignature !== "ice" && (
                <div
                  className={`flex items-center space-x-3 rounded-lg border-2 p-4 transition-all cursor-pointer ${selectedSignature === "if"
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-primary/50"
                    }`}
                  onClick={() => setSelectedSignature("if")}
                >
                  <RadioGroupItem value="if" id="if" />
                  <div className="flex-1">
                    <Label htmlFor="if" className="cursor-pointer flex items-center gap-2">
                      <span className="font-medium">IF (Identifiant Fiscal)</span>
                      {selectedSignature === "if" && <Badge className="bg-primary">Sélectionné</Badge>}
                    </Label>
                    <p className="text-sm text-muted-foreground mt-1 font-mono">{ifNumber}</p>
                  </div>
                </div>
              )}

              {hasIf && selectedSignature === "ice" && (
                <div className="text-sm text-muted-foreground italic pl-4">
                  L'option IF est masquée car ICE est sélectionné.
                </div>
              )}
            </RadioGroup>
          </div>

          {!hasIce && !hasIf && (
            <div className="rounded-lg border border-amber-500/50 bg-amber-500/10 p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-amber-500 mt-0.5" />
                <div className="text-sm text-amber-700 dark:text-amber-300">
                  <p className="font-medium mb-1">Aucune signature détectée</p>
                  <p>Impossible de créer un template sans ICE ou IF.</p>
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleCancel} disabled={isCreating}>
            Ignorer
          </Button>
          <Button
            onClick={handleCreate}
            disabled={!selectedSignature || isCreating}
            className="gap-2"
          >
            <Sparkles className="h-4 w-4" />
            {isCreating ? "Création..." : "Créer Template"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
