"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { FileText, Scan, Loader2, CheckCircle2, Zap, Eye } from "lucide-react"
import type { LocalInvoice } from "@/lib/types"
import { formatFileSize, formatDate } from "@/lib/utils"
import { toast } from "sonner"

interface UploadedFilesPageProps {
  invoices: LocalInvoice[]
  onProcessAll: () => Promise<void>
  onProcessSingle: (invoice: LocalInvoice) => Promise<void>
  onView: (invoice: LocalInvoice) => void
  onNavigateToDashboard: () => void
}

export function UploadedFilesPage({
  invoices,
  onProcessAll,
  onProcessSingle,
  onView,
  onNavigateToDashboard,
}: UploadedFilesPageProps) {
  const [isProcessingAll, setIsProcessingAll] = useState(false)
  const [processingIds, setProcessingIds] = useState<Set<number>>(new Set())

  const handleProcessAll = async () => {
    setIsProcessingAll(true)
    try {
      await onProcessAll()
      toast.success(`${invoices.length} facture(s) traitée(s) avec succès`)
    } catch (error) {
      toast.error("Erreur lors du traitement")
    } finally {
      setIsProcessingAll(false)
    }
  }

  const handleProcessSingle = async (invoice: LocalInvoice) => {
    setProcessingIds(prev => new Set(prev).add(invoice.id))
    try {
      await onProcessSingle(invoice)
    } finally {
      setProcessingIds(prev => {
        const newSet = new Set(prev)
        newSet.delete(invoice.id)
        return newSet
      })
    }
  }

  const allProcessed = invoices.every(inv => inv.status !== "pending")

  return (
    <div className="space-y-6">
      {/* En-tête */}
      <Card className="border-primary/50 bg-primary/5">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                <FileText className="h-6 w-6 text-primary" />
              </div>
              <div>
                <CardTitle className="text-2xl">Fichiers Uploadés</CardTitle>
                <CardDescription>
                  {invoices.length} fichier{invoices.length > 1 ? "s" : ""} prêt{invoices.length > 1 ? "s" : ""} à être traité{invoices.length > 1 ? "s" : ""}
                </CardDescription>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {allProcessed ? (
                <Button className="gap-2" onClick={onNavigateToDashboard}>
                  <CheckCircle2 className="h-5 w-5" />
                  Voir le Tableau de Bord
                </Button>
              ) : (
                <Button
                  className="gap-2"
                  onClick={handleProcessAll}
                  disabled={isProcessingAll || invoices.length === 0}
                >
                  {isProcessingAll ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      Traitement en cours...
                    </>
                  ) : (
                    <>
                      <Zap className="h-5 w-5" />
                      Traiter Tout ({invoices.length})
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Tableau des fichiers */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-border/50 hover:bg-transparent">
                  <TableHead className="w-16">Aperçu</TableHead>
                  <TableHead>Nom du fichier</TableHead>
                  <TableHead>Date upload</TableHead>
                  <TableHead>Taille</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invoices.map((invoice) => {
                  const isProcessing = processingIds.has(invoice.id) || invoice.isProcessing
                  const isImage = /\.(jpg|jpeg|png|gif|webp)$/i.test(invoice.filename)

                  return (
                    <TableRow key={invoice.id} className="border-border/50">
                      <TableCell>
                        <div className="h-12 w-12 rounded-lg border border-border/50 bg-muted/50 flex items-center justify-center overflow-hidden relative">
                          {isProcessing && (
                            <div className="absolute inset-0 bg-primary/20 flex items-center justify-center">
                              <Loader2 className="h-4 w-4 animate-spin text-primary" />
                            </div>
                          )}
                          {invoice.fileUrl && isImage ? (
                            <img
                              src={invoice.fileUrl}
                              alt={invoice.filename}
                              className="h-full w-full object-cover"
                            />
                          ) : (
                            <FileText className="h-5 w-5 text-muted-foreground" />
                          )}
                        </div>
                      </TableCell>

                      <TableCell className="font-medium">{invoice.filename}</TableCell>
                      <TableCell className="text-muted-foreground">{formatDate(invoice.createdAt)}</TableCell>
                      <TableCell className="text-muted-foreground">{formatFileSize(invoice.fileSize)}</TableCell>
                      <TableCell>
                        {invoice.status === "pending" && (
                          <Badge className="bg-amber-400/10 text-amber-400 border-amber-400/30">
                            En attente
                          </Badge>
                        )}
                        {invoice.status === "processing" && (
                          <Badge className="bg-sky-400/10 text-sky-400 border-sky-400/30">
                            En cours
                          </Badge>
                        )}
                        {invoice.status === "processed" && (
                          <Badge className="bg-primary/10 text-primary border-primary/30">
                            Traité
                          </Badge>
                        )}
                      </TableCell>

                      <TableCell>
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onView(invoice)}
                            className="gap-1"
                          >
                            <Eye className="h-4 w-4" />
                            Voir
                          </Button>
                          {invoice.status === "pending" && (
                            <Button
                              size="sm"
                              onClick={() => handleProcessSingle(invoice)}
                              disabled={isProcessing}
                              className="gap-1"
                            >
                              {isProcessing ? (
                                <>
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                  Traitement...
                                </>
                              ) : (
                                <>
                                  <Scan className="h-4 w-4" />
                                  Traiter
                                </>
                              )}
                            </Button>
                          )}
                          {invoice.status === "processed" && (
                            <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/30">
                              ✓ Prêt
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}