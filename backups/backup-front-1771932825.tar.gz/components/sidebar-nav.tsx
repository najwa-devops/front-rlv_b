"use client"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Badge } from "@/components/ui/badge"
import {
  LayoutDashboard,
  Upload,
  Settings,
  User,
  LogOut,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Menu,
  Sparkles,
  Sun,
  Moon,
  Clock,
  FileText,
  CheckCircle2,
  Building2,
  List
} from "lucide-react"
import { useState, useEffect } from "react"
import { useIsMobile } from "@/hooks/use-mobile"
import { useTheme } from "@/components/theme-provider"

interface NavItem {
  id: string
  label: string
  icon: any
  badge?: number
  children?: NavItem[]
}

interface SidebarNavProps {
  currentPage: string
  onNavigate: (page: string) => void
  isAdmin?: boolean
  pendingCount?: number
}

export function SidebarNav({ currentPage, onNavigate, isAdmin = false, pendingCount = 0 }: SidebarNavProps) {
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [openMenus, setOpenMenus] = useState<string[]>([])
  const isMobile = useIsMobile()
  const { theme, toggleTheme } = useTheme()

  useEffect(() => {
    setMounted(true)
  }, [])

  // Gérer l'ouverture automatique du menu parent si une sous-page est active
  useEffect(() => {
    const parent = navItems.find(item =>
      item.children?.some(child => child.id === currentPage)
    )
    if (parent && !openMenus.includes(parent.id)) {
      setOpenMenus(prev => [...prev, parent.id])
    }
  }, [currentPage])

  const navItems: NavItem[] = [
    { id: "dashboard", label: "Tableau de bord", icon: LayoutDashboard },
    {
      id: "facturation-parent",
      label: "Facturisation",
      icon: FileText,
      children: [
        { id: "upload", label: "Upload de facturisation", icon: Upload },
        {
          id: "invoices",
          label: "Facturisation en traitement",
          icon: Clock,
          badge: pendingCount > 0 ? pendingCount : undefined
        },
        { id: "validated", label: "Factures validées", icon: CheckCircle2 },
      ]
    },
    {
      id: "bank-parent",
      label: "Relevé bancaire",
      icon: Building2,
      children: [
        { id: "upload-bank", label: "Uploader relevé bancaire", icon: Upload },
        { id: "bank-list", label: "Liste des relevés bancaires", icon: List },
        { id: "bank-validated", label: "Relevés bancaires validés", icon: CheckCircle2 },
      ]
    },
    {
      id: "settings-parent",
      label: "Paramètres",
      icon: Settings,
      children: [
        { id: "templates", label: "Groupement", icon: Sparkles },
        { id: "bank-settings", label: "Configuration Bancaire", icon: Building2 },
        ...(isAdmin ? [{ id: "patterns", label: "Pattern", icon: Settings }] : []),
      ]
    },
  ]

  const toggleMenu = (id: string) => {
    setOpenMenus(prev =>
      prev.includes(id) ? prev.filter(m => m !== id) : [...prev, id]
    )
  }

  const handleNavigate = (page: string) => {
    onNavigate(page)
    if (isMobile) setMobileOpen(false)
  }

  const renderNavItem = (item: NavItem, isChild = false) => {
    const isActive = currentPage === item.id
    const isExpanded = openMenus.includes(item.id)
    const hasChildren = item.children && item.children.length > 0
    const IconComponent = item.icon

    // Pour les parents, on vérifie si un de leurs enfants est actif
    const isParentActive = item.children?.some(child => child.id === currentPage)

    return (
      <div key={item.id} className="w-full">
        <Button
          variant="ghost"
          className={cn(
            "w-full justify-start gap-3 transition-all duration-200",
            !isMobile && collapsed && "justify-center px-2",
            isChild && "pl-9 text-sm h-9",
            isActive || (isParentActive && !isExpanded)
              ? "bg-primary/10 text-primary font-medium"
              : "text-muted-foreground hover:text-foreground hover:bg-accent/50",
          )}
          onClick={() => {
            if (hasChildren) {
              toggleMenu(item.id)
            } else {
              handleNavigate(item.id)
            }
          }}
        >
          <IconComponent className={cn("h-4 w-4 shrink-0", (isActive || isParentActive) && "text-primary")} />
          {(isMobile || !collapsed) && (
            <div className="flex items-center justify-between w-full">
              <span className="truncate">{item.label}</span>
              <div className="flex items-center gap-2">
                {item.badge && (
                  <Badge className="h-5 px-1.5 bg-amber-500 text-white border-none text-[10px]">
                    {item.badge}
                  </Badge>
                )}
                {hasChildren && (
                  <ChevronDown className={cn(
                    "h-3 w-3 transition-transform duration-200",
                    isExpanded ? "rotate-0" : "-rotate-90"
                  )} />
                )}
              </div>
            </div>
          )}
        </Button>

        {hasChildren && isExpanded && (isMobile || !collapsed) && (
          <div className="mt-1 flex flex-col gap-1 border-l ml-5 border-border/50">
            {item.children?.map(child => renderNavItem(child, true))}
          </div>
        )}
      </div>
    )
  }

  const NavContent = () => (
    <>
      <div className="flex h-16 items-center justify-between border-b border-border/50 px-4 shrink-0">
        {(!collapsed || isMobile) && (
          <div className="flex items-center gap-3">
            <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-primary/20">
              <Sparkles className="h-5 w-5 text-primary" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-foreground tracking-tight">FactureOCR</span>
              <span className="text-[10px] text-muted-foreground">Intelligence Documentaire</span>
            </div>
          </div>
        )}
        {collapsed && !isMobile && (
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/20 mx-auto">
            <Sparkles className="h-5 w-5 text-primary" />
          </div>
        )}
        {!isMobile && (
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-muted-foreground hover:text-foreground"
            onClick={() => setCollapsed(!collapsed)}
          >
            {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto overflow-x-hidden p-3 custom-scrollbar">
        <p
          className={cn(
            "mb-3 px-3 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70",
            collapsed && !isMobile && "sr-only",
          )}
        >
          Menu Principal
        </p>
        <div className="flex flex-col gap-1">
          {navItems.map((item) => renderNavItem(item))}
        </div>
      </div>

      <div className="border-t border-border/50 p-3 shrink-0">
        <Button
          variant="ghost"
          className={cn(
            "w-full justify-start gap-3 mb-2 text-muted-foreground hover:text-foreground hover:bg-accent",
            !isMobile && collapsed && "justify-center px-2",
          )}
          onClick={toggleTheme}
        >
          {mounted && theme === "dark" ? <Sun className="h-4 w-4 shrink-0" /> : <Moon className="h-4 w-4 shrink-0" />}
          {(isMobile || !collapsed) && <span>{mounted && theme === "dark" ? "Mode clair" : "Mode sombre"}</span>}
        </Button>

        <div className={cn("rounded-lg bg-accent/50 p-2 mb-2", collapsed && !isMobile && "p-2")}>
          <Button
            variant="ghost"
            className={cn(
              "w-full justify-start gap-3 h-auto p-0 hover:bg-transparent",
              !isMobile && collapsed && "justify-center",
            )}
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/20 shrink-0">
              <User className="h-4 w-4 text-primary" />
            </div>
            {(isMobile || !collapsed) && (
              <div className="flex flex-col items-start min-w-0">
                <span className="text-xs font-semibold text-foreground truncate w-full uppercase">Utilisateur</span>
                {isAdmin && <span className="text-[10px] text-primary font-medium tracking-tight">Administrateur</span>}
              </div>
            )}
          </Button>
        </div>
        <Button
          variant="ghost"
          className={cn(
            "w-full justify-start gap-3 text-muted-foreground hover:text-destructive hover:bg-destructive/10",
            !isMobile && collapsed && "justify-center px-2",
          )}
        >
          <LogOut className="h-4 w-4 shrink-0" />
          {(isMobile || !collapsed) && <span>Déconnexion</span>}
        </Button>
      </div>
    </>
  )

  if (isMobile) {
    return (
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="fixed left-4 top-4 z-50 md:hidden bg-background/80 backdrop-blur-sm border shadow-sm">
            <Menu className="h-5 w-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-72 p-0 border-border/50">
          <div className="flex h-full flex-col">
            <NavContent />
          </div>
        </SheetContent>
      </Sheet>
    )
  }

  return (
    <aside
      className={cn(
        "flex h-screen flex-col border-r border-border/50 transition-all duration-300 bg-card/30 backdrop-blur-md",
        collapsed ? "w-[72px]" : "w-64",
      )}
    >
      <NavContent />
    </aside>
  )
}
