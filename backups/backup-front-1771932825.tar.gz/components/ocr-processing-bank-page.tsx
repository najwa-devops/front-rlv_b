"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import dynamic from "next/dynamic"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
    ArrowLeft,
    FileText,
    Save,
    Target,
    X,
    Loader2,
    CheckCircle,
    ZoomIn,
    ZoomOut,
    Download,
    AlertTriangle,
    RefreshCw,
    Eye,
} from "lucide-react"
import type { BankStatementV2, BankTransactionV2 } from "@/lib/types"
import { toast } from "sonner"
import { formatDate } from "@/lib/utils"
import { BankTransactionTable } from "./bank-statement-table"
import { api } from "@/lib/api"
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"

// CSS pour react-pdf
import 'react-pdf/dist/Page/TextLayer.css';
import 'react-pdf/dist/Page/AnnotationLayer.css';

// Import dynamique de react-pdf
const Document = dynamic(
    () => import("react-pdf").then((mod) => mod.Document),
    { ssr: false }
)

const Page = dynamic(
    () => import("react-pdf").then((mod) => mod.Page),
    { ssr: false }
)

interface OcrProcessingBankPageProps {
    statement: BankStatementV2
    file: File | null
    onBack: () => void
    onSave: (statement: BankStatementV2) => void
}

export function OcrProcessingBankPage({
    statement,
    file,
    onBack,
    onSave,
}: OcrProcessingBankPageProps) {
    const [transactions, setTransactions] = useState<BankTransactionV2[]>(
        Array.isArray(statement.transactionsPreview) ? statement.transactionsPreview as unknown as BankTransactionV2[] : []
    )
    const [isSaving, setIsSaving] = useState(false)
    const [isProcessingOcr, setIsProcessingOcr] = useState(false)
    const [zoom, setZoom] = useState(100)
    const [documentUrl, setDocumentUrl] = useState<string | null>(null)
    const [isLoadingDocument, setIsLoadingDocument] = useState(true)
    const [numPages, setNumPages] = useState<number>(1)
    const [pageNumber, setPageNumber] = useState(1)
    const [documentRendered, setDocumentRendered] = useState(false)
    const [isSelectingPosition, setIsSelectingPosition] = useState<string | null>(null)
    const [selectedFieldKey, setSelectedFieldKey] = useState<string | null>(null)

    const imageContainerRef = useRef<HTMLDivElement>(null)

    const isPdf = statement.filename.match(/\.pdf$/i)
    const isImage = statement.filename.match(/\.(jpg|jpeg|png|gif|webp)$/i)
    const isExcel = statement.filename.match(/\.(xlsx|xls)$/i)

    // Configuration PDF.js Worker
    useEffect(() => {
        ; (async () => {
            const { pdfjs } = await import("react-pdf")
            pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`
        })()
    }, [])

    useEffect(() => {
        if (file) {
            const url = URL.createObjectURL(file)
            setDocumentUrl(url)
            setIsLoadingDocument(false)
        } else if (statement.filename) {
            // Use the API endpoint to serve the file
            const url = api.getBankStatementImageUrl(statement.filename)
            setDocumentUrl(url)
            setIsLoadingDocument(false)
        }
    }, [file, statement.filename])

    const handleOcrExtract = async () => {
        setIsProcessingOcr(true)
        const toastId = toast.loading("Traitement asynchrone du relevé lancé...")

        try {
            await api.processBankStatement(statement.id)
            toast.dismiss(toastId)
            toast.success("Traitement lancé en arrière-plan. Suivez la progression sur la liste des relevés.")
        } catch (error) {
            toast.dismiss(toastId)
            toast.error("Erreur lors du lancement du traitement OCR")
        } finally {
            setIsProcessingOcr(false)
        }
    }

    const updateTransactionValue = (id: number, field: keyof BankTransactionV2, value: any) => {
        setTransactions(prev => prev.map(tx => tx.id === id ? { ...tx, [field]: value } : tx))
    }

    const handleSave = async () => {
        setIsSaving(true)
        try {
            if (statement.status === "VALIDATED") {
                toast.info("Relevé déjà validé")
                return
            }

            // Attempt to validate
            await api.validateBankStatement(statement.id)
            onSave({ ...statement, status: "VALIDATED" })
            toast.success("Relevé bancaire validé avec succès")
        } catch (error: any) {
            console.error("Erreur validation:", error)

            // Extract error message
            let info = "Erreur lors de la validation"
            try {
                // If it's a "not ready" error, provide actionable feedback
                if (error.message && (error.message.includes("non prêt") || error.message.includes("not ready"))) {
                    info = "Le relevé n'est pas prêt pour la validation. Vérifiez qu'il n'y a pas d'erreurs (statut actuel: " + statement.status + ")."
                } else {
                    info = error.message || info
                }
            } catch (e) { }

            toast.error(info)
        } finally {
            setIsSaving(false)
        }
    }

    const startSelection = (key: string) => {
        setIsSelectingPosition(key)
        setSelectedFieldKey(key)
        toast.info("Sélectionnez la zone dans le document")
    }

    const cancelPositionSelection = () => {
        setIsSelectingPosition(null)
        setSelectedFieldKey(null)
    }

    const clearFieldValue = (key: string) => {
        // No longer used for fields
    }

    const handleTransactionUpdate = async (updatedTx: BankTransactionV2) => {
        try {
            const result = await api.updateBankTransaction(updatedTx.id, {
                isLinked: updatedTx.isLinked,
                compte: updatedTx.compte,
                categorie: updatedTx.categorie,
                libelle: updatedTx.libelle
            })
            setTransactions(prev => prev.map(tx => tx.id === result.id ? result : tx))
            toast.success("Transaction mise à jour")
        } catch (error) {
            console.error("Erreur mise à jour transaction:", error)
            toast.error("Erreur lors de la mise à jour")
        }
    }

    return (
        <div className="min-h-screen bg-background p-6">
            <div className="mb-6 flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <Button variant="ghost" size="icon" onClick={onBack}>
                        <ArrowLeft className="h-5 w-5" />
                    </Button>
                    <div>
                        <h1 className="text-xl font-bold text-foreground">
                            Prévisualisation du Relevé
                        </h1>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                            <span>{statement.transactionCount || 0} transactions identifiées</span>
                        </div>
                    </div>
                </div>
                <div className="flex items-center gap-3">
                    <Dialog>
                        <DialogTrigger asChild>
                            <Button
                                variant="outline"
                                className="gap-2 bg-transparent border-primary/20 hover:bg-primary/5"
                            >
                                <Eye className="h-4 w-4" />
                                Inspecter Texte OCR
                            </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-[50vw] sm:max-w-[50vw] w-full max-h-[90vh] flex flex-col">
                            <DialogHeader>
                                <DialogTitle>Inspection du Texte Extrait par OCR</DialogTitle>
                            </DialogHeader>
                            <Tabs defaultValue="cleaned" className="flex-1 flex flex-col overflow-hidden">
                                <TabsList className="mb-4">
                                    <TabsTrigger value="cleaned">Texte Nettoyé</TabsTrigger>
                                    <TabsTrigger value="raw">Texte Brut (Raw)</TabsTrigger>
                                </TabsList>
                                <TabsContent value="cleaned" className="flex-1 overflow-hidden">
                                    <ScrollArea className="h-[60vh] w-full rounded-md border p-4 bg-muted/20">
                                        <pre className="text-xs whitespace-pre-wrap font-mono">
                                            {statement.cleanedOcrText || "Aucun texte nettoyé disponible."}
                                        </pre>
                                    </ScrollArea>
                                </TabsContent>
                                <TabsContent value="raw" className="flex-1 overflow-hidden">
                                    <ScrollArea className="h-[60vh] w-full rounded-md border p-4 bg-muted/20">
                                        <pre className="text-xs whitespace-pre-wrap font-mono">
                                            {statement.rawOcrText || "Aucun texte brut disponible."}
                                        </pre>
                                    </ScrollArea>
                                </TabsContent>
                            </Tabs>
                        </DialogContent>
                    </Dialog>
                    <Button
                        variant="outline"
                        className="gap-2 bg-transparent"
                        onClick={handleOcrExtract}
                        disabled={isProcessingOcr}
                    >
                        <RefreshCw className={`h-4 w-4 ${isProcessingOcr ? "animate-spin" : ""}`} />
                        Reprocesser OCR
                    </Button>
                    <Button
                        className="gap-2"
                        onClick={handleSave}
                        disabled={isSaving}
                    >
                        {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                        Valider le relevé
                    </Button>
                </div>
            </div>

            {statement.validationErrors && (
                <div className="mb-6 px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-lg flex items-start gap-3 text-red-500">
                    <AlertTriangle className="h-5 w-5 mt-0.5" />
                    <div>
                        <p className="text-sm font-semibold text-red-700">Erreur de Traitement</p>
                        <p className="text-sm">{statement.validationErrors}</p>
                    </div>
                </div>
            )}

            <div className="grid gap-6 lg:grid-cols-2 mt-6">
                {/* Document view */}
                <Card className="h-[calc(100vh-200px)] overflow-hidden flex flex-col">
                    <CardHeader className="py-3 px-4 border-b">
                        <div className="flex items-center justify-between">
                            <CardTitle className="text-sm font-medium">Document</CardTitle>
                            <div className="flex items-center gap-2">
                                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setZoom(z => Math.max(50, z - 25))}>
                                    <ZoomOut className="h-4 w-4" />
                                </Button>
                                <span className="text-xs w-8 text-center">{zoom}%</span>
                                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setZoom(z => Math.min(200, z + 25))}>
                                    <ZoomIn className="h-4 w-4" />
                                </Button>
                            </div>
                        </div>
                    </CardHeader>
                    <CardContent className="flex-1 overflow-auto p-4 bg-muted/30">
                        <div ref={imageContainerRef} className="relative inline-block origin-top-left" style={{ transform: `scale(${zoom / 100}%)` }}>
                            {isLoadingDocument && (
                                <div className="flex h-96 w-full items-center justify-center">
                                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                                </div>
                            )}
                            {documentUrl && isPdf && (
                                <Document
                                    file={documentUrl}
                                    onLoadSuccess={({ numPages }) => {
                                        setNumPages(numPages)
                                        setDocumentRendered(true)
                                        setIsLoadingDocument(false)
                                    }}
                                >
                                    <Page pageNumber={pageNumber} width={600} />
                                </Document>
                            )}
                            {documentUrl && isImage && (
                                <img src={documentUrl} alt="Document" className="max-w-full" onLoad={() => setIsLoadingDocument(false)} />
                            )}
                            {isExcel && (
                                <div className="flex flex-col h-full w-full items-center justify-center p-12 text-center bg-background rounded-xl border border-dashed">
                                    <div className="h-20 w-20 rounded-2xl bg-emerald-500/10 flex items-center justify-center mb-4">
                                        <FileText className="h-10 w-10 text-emerald-500" />
                                    </div>
                                    <h3 className="text-lg font-semibold text-foreground">Fichier Excel (.xlsx/.xls)</h3>
                                    <p className="text-sm text-muted-foreground mt-2 max-w-xs">
                                        Ce fichier est un tableau Excel. Le texte a été extrait directement des cellules pour le traitement.
                                    </p>
                                    <Button variant="outline" className="mt-6 gap-2" onClick={() => window.open(api.getBankStatementImageUrl(statement.filename), '_blank')}>
                                        <Download className="h-4 w-4" />
                                        Télécharger le fichier
                                    </Button>
                                </div>
                            )}
                        </div>
                    </CardContent>
                    {numPages > 1 && (
                        <div className="p-2 border-t flex items-center justify-center gap-4">
                            <Button size="sm" variant="ghost" onClick={() => setPageNumber(p => Math.max(1, p - 1))} disabled={pageNumber === 1}>
                                Précédent
                            </Button>
                            <span className="text-xs">Page {pageNumber} sur {numPages}</span>
                            <Button size="sm" variant="ghost" onClick={() => setPageNumber(p => Math.min(numPages, p + 1))} disabled={pageNumber === numPages}>
                                Suivant
                            </Button>
                        </div>
                    )}
                </Card>

                {/* Transactions table */}
                <div className="space-y-4">
                    <BankTransactionTable
                        transactions={transactions}
                        statement={statement}
                        onUpdate={handleTransactionUpdate}
                    />

                    <Card className="border-primary/20 bg-primary/5">
                        <CardContent className="pt-4">
                            <div className="flex items-start gap-3">
                                <FileText className="h-5 w-5 text-primary mt-0.5" />
                                <div>
                                    <p className="text-sm font-medium">Conseil</p>
                                    <p className="text-xs text-muted-foreground mt-1">
                                        Vérifiez attentivement les dates et les montants avant de valider le relevé pour assurer une comptabilité précise.
                                    </p>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    )
}
