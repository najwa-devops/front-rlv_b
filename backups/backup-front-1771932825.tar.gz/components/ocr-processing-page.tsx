"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import dynamic from "next/dynamic"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Progress } from "@/components/ui/progress"
import {
  ArrowLeft,
  FileText,
  Save,
  Target,
  X,
  Loader2,
  Plus,
  Sparkles,
  Trash2,
  CheckCircle,
  AlertTriangle,
  RefreshCw,
  ChevronDown,
  Download,
  ZoomIn,
  ZoomOut,
  Lightbulb,
  Check,
  Scan,
  Building2,
  Settings,
} from "lucide-react"
import type { LocalInvoice, LocalTemplate, InvoiceField, Tier } from "@/lib/types"
import { api } from "@/lib/api"
import { formatDate, normalizeStatus } from "@/lib/utils"
import { toast } from "sonner"
import { ConfidenceBadge } from "@/components/confidence-badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { invoiceDtoToLocal, ParseBackendFieldsData } from "@/lib/utils"
import { DynamicTemplateWizard } from "@/components/dynamic-template-wizard"

// CSS pour react-pdf
import 'react-pdf/dist/Page/TextLayer.css';
import 'react-pdf/dist/Page/AnnotationLayer.css';

// Import dynamique de react-pdf
const Document = dynamic(
  () => import("react-pdf").then((mod) => mod.Document),
  { ssr: false }
)

const Page = dynamic(
  () => import("react-pdf").then((mod) => mod.Page),
  { ssr: false }
)

interface OcrProcessingPageProps {
  invoice: LocalInvoice
  file: File | null
  templates: LocalTemplate[]
  onBack: () => void
  onSave: (invoice: LocalInvoice, template?: LocalTemplate) => void
  isDemoMode?: boolean
}

interface SelectionBox {
  startX: number
  startY: number
  endX: number
  endY: number
}

interface Warning {
  field: string
  message: string
  suggestion?: string
}

export function OcrProcessingPage({
  invoice,
  file,
  templates,
  onBack,
  onSave,
  isDemoMode = false,
}: OcrProcessingPageProps) {

  const [fields, setFields] = useState<InvoiceField[]>(invoice.fields)
  const [customFields, setCustomFields] = useState<InvoiceField[]>([])
  const allFields = [...fields, ...customFields]
  const [extractedText, setExtractedText] = useState(invoice.rawOcrText || invoice.extractedText || "")
  const [isProcessingOcr, setIsProcessingOcr] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [isValidating, setIsValidating] = useState(false)
  const [isSelectingPosition, setIsSelectingPosition] = useState<string | null>(null)
  const [selectionMode, setSelectionMode] = useState<'VALUE' | 'PATTERN'>("VALUE")
  const [fieldPatterns, setFieldPatterns] = useState<Record<string, string>>({})
  const [selectionBox, setSelectionBox] = useState<SelectionBox | null>(null)
  const [isDrawing, setIsDrawing] = useState(false)
  const [selectedFieldKey, setSelectedFieldKey] = useState<string | null>(null)
  const [matchedTemplate, setMatchedTemplate] = useState<LocalTemplate | null>(null)
  const [newFieldLabel, setNewFieldLabel] = useState("")
  const [showAddField, setShowAddField] = useState(false)
  const [pendingFields, setPendingFields] = useState<string[]>(invoice.pendingFields || [])
  const [warnings, setWarnings] = useState<Warning[]>([])
  const [showOcrText, setShowOcrText] = useState(false)
  const [zoom, setZoom] = useState(100)
  const [status, setStatus] = useState<LocalInvoice["status"]>(invoice.status || "pending")
  const [missingFields, setMissingFields] = useState<string[]>(invoice.missingFields || [])
  const [lowConfidenceFields, setLowConfidenceFields] = useState<string[]>(invoice.lowConfidenceFields || [])
  const [overallConfidence, setOverallConfidence] = useState<number | undefined>(invoice.overallConfidence)
  const [extractionMethod, setExtractionMethod] = useState<string | undefined>(invoice.extractionMethod)
  const [templateDetected, setTemplateDetected] = useState<boolean>(invoice.templateDetected || false)
  const [documentUrl, setDocumentUrl] = useState<string | null>(null)
  const [isLoadingDocument, setIsLoadingDocument] = useState(true)
  const [documentError, setDocumentError] = useState<string | null>(null)
  const [numPages, setNumPages] = useState<number>(1)
  const [pageNumber, setPageNumber] = useState(1)
  const [documentRendered, setDocumentRendered] = useState(false)
  const [isCreatingTemplate, setIsCreatingTemplate] = useState(false)
  const [selectedSignature, setSelectedSignature] = useState<"ice" | "ifNumber" | null>(null)
  const [canCreateTemplate, setCanCreateTemplate] = useState<boolean>(invoice.canCreateTemplate || false)
  const [tier, setTier] = useState<Tier | null>(invoice.tier || null)
  const [hasShownTierToast, setHasShownTierToast] = useState(false)
  const [focusedFieldKey, setFocusedFieldKey] = useState<string | null>(null)

  const imageContainerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Synchroniser extractedText si la facture change (ex: après un rechargement parent)
  useEffect(() => {
    if (invoice.rawOcrText || invoice.extractedText) {
      setExtractedText(invoice.rawOcrText || invoice.extractedText || "")
    }
  }, [invoice.rawOcrText, invoice.extractedText])

  const isImage = invoice.filename.match(/\.(jpg|jpeg|png|gif|webp)$/i)
  const isPdf = invoice.filename.match(/\.pdf$/i)

  // Configuration PDF.js Worker
  useEffect(() => {
    ; (async () => {
      const { pdfjs } = await import("react-pdf")
      pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`
    })()
  }, [])

  useEffect(() => {
    if (!selectedSignature && canCreateTemplate) {
      const iceValue = fields.find(f => f.key === "ice")?.value
      const ifValue = fields.find(f => f.key === "ifNumber")?.value

      if (iceValue && !ifValue) setSelectedSignature("ice")
      else if (!iceValue && ifValue) setSelectedSignature("ifNumber")
    }
  }, [canCreateTemplate, fields, selectedSignature])

  // Toast si Tier existe mais sans configuration comptable
  useEffect(() => {
    if (tier && !tier.hasAccountingConfig && !hasShownTierToast) {
      toast.warning(
        "Veuillez configurer les comptes comptables pour ce fournisseur",
        {
          duration: 5000,
          action: {
            label: "Plus tard",
            onClick: () => { }
          }
        }
      )
      setHasShownTierToast(true)
    }
  }, [tier, hasShownTierToast])

  // ADDED: Gestion de la sélection de texte automatique pour extraction
  useEffect(() => {
    const handleSelection = () => {
      // Uniquement si on est en train de sélectionner une zone pour un champ
      if (isSelectingPosition) {
        const selection = window.getSelection()
        const selectedText = selection?.toString().trim()

        console.log(`[OCR] handleSelection triggered for ${isSelectingPosition}`)
        console.log(`[OCR] Selected text:`, selectedText)
        console.log(`[OCR] Selection mode:`, selectionMode)

        if (selectedText) {
          console.log(`[OCR] Texte sélectionné manuellement pour ${isSelectingPosition} (Mode: ${selectionMode}):`, selectedText)

          if (selectionMode === "VALUE") {
            setFields(prev => prev.map(f =>
              f.key === isSelectingPosition ? { ...f, value: selectedText, detected: true } : f
            ))

            setCustomFields(prev => prev.map(f =>
              f.key === isSelectingPosition ? { ...f, value: selectedText, detected: true } : f
            ))

            toast.success(`${selectedText} assigné à ${allFields.find(f => f.key === isSelectingPosition)?.label}`, {
              icon: "🎯"
            })
          } else {
            // Mode PATTERN
            setFieldPatterns(prev => ({
              ...prev,
              [isSelectingPosition]: selectedText
            }))

            toast.info(`Pattern détecté: "${selectedText}"`, {
              description: "Pattern capturé pour l'apprentissage",
              icon: "🔍"
            })
          }

          // Note: On ne ferme pas isSelectingPosition car l'utilisateur 
          // peut encore vouloir dessiner le rectangle pour la position visuelle.
        }
      }
    }

    document.addEventListener("mouseup", handleSelection)
    return () => document.removeEventListener("mouseup", handleSelection)
  }, [isSelectingPosition, allFields, selectionMode])

  // Chargement du document
  useEffect(() => {
    const loadDocumentUrl = async () => {
      setIsLoadingDocument(true)
      setDocumentError(null)

      try {
        // CAS 1: Fichier local
        if (file) {
          const url = URL.createObjectURL(file)
          setDocumentUrl(url)
          setIsLoadingDocument(false)
          return
        }

        // CAS 2: Fichier sur serveur
        if (invoice.filePath || invoice.filename) {
          const url = api.getFileUrl(invoice.filePath || invoice.filename)
          setDocumentUrl(url)
          setIsLoadingDocument(false)
          return
        }

        setDocumentError("Aucun fichier disponible")
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Erreur inconnue"
        setDocumentError(`Erreur: ${errorMessage}`)
      } finally {
        setIsLoadingDocument(false)
      }
    }

    loadDocumentUrl()

    return () => {
      if (file && documentUrl?.startsWith("blob:")) {
        URL.revokeObjectURL(documentUrl)
      }
    }
  }, [file, invoice.filePath, isDemoMode])

  const getStatusBadge = () => {
    switch (status) {
      case "pending":
        return <Badge className="bg-amber-500 text-white">En attente</Badge>
      case "processing":
        return <Badge className="bg-blue-500 text-white">En cours de traitement</Badge>
      case "treated":
        return <Badge className="bg-purple-500 text-white">OCR terminé</Badge>
      case "ready_to_validate":
        return <Badge className="bg-blue-600 text-white">Prêt à valider</Badge>
      case "validated":
        return <Badge className="bg-green-600 text-white">Validé </Badge>
      case "error":
        return <Badge className="bg-red-500 text-white">Erreur</Badge>
      default:
        return <Badge className="bg-amber-500 text-white">En attente</Badge>
    }
  }

  const checkWarnings = () => {
    const newWarnings: Warning[] = []

    const ht = Number.parseFloat(String(fields.find((f) => f.key === "amountHT")?.value || "0"))
    const tva = Number.parseFloat(String(fields.find((f) => f.key === "tva")?.value || "0"))
    const ttc = Number.parseFloat(String(fields.find((f) => f.key === "amountTTC")?.value || "0"))

    if (ht > 0 && ttc > 0) {
      const expectedTva = ht * 0.2
      if (tva > 0 && Math.abs(tva - expectedTva) > 1) {
        newWarnings.push({
          field: "tva",
          message: `La TVA detectee (${tva} DH) semble incorrecte.`,
          suggestion: `${expectedTva.toFixed(2)}`,
        })
      }

      const expectedTtc = ht + (tva || expectedTva)
      if (Math.abs(ttc - expectedTtc) > 1) {
        newWarnings.push({
          field: "amountTTC",
          message: `Le TTC detecte (${ttc} DH) semble incorrect.`,
          suggestion: `${expectedTtc.toFixed(2)}`,
        })
      }
    }

    setWarnings(newWarnings)
  }

  const handleOcrExtract = async (forcedTemplateId?: number) => {
    setIsProcessingOcr(true)
    setStatus("processing")

    const loadingToast = toast.loading(
      forcedTemplateId ? "Extraction avec le nouveau template..." : "Traitement OCR en cours...\nCela peut prendre 10-30 secondes",
      { duration: Infinity }
    )

    try {
      if (isDemoMode) {
        await new Promise((resolve) => setTimeout(resolve, 1500))

        const demoText = `FACTURE N FAC-2026-001...`
        setExtractedText(demoText)

        const updatedFields = fields.map((f) => {
          switch (f.key) {
            case "invoiceNumber": return { ...f, value: "FAC-2026-001", detected: true }
            case "invoiceDate": return { ...f, value: "08/01/2026", detected: true }
            case "supplier": return { ...f, value: "EVOLEO SARL", detected: true }
            case "ice": return { ...f, value: "003501940000019", detected: true }
            case "amountHT": return { ...f, value: "23000.00", detected: true }
            case "tva": return { ...f, value: "4600.00", detected: true }
            case "amountTTC": return { ...f, value: "27600.00", detected: true }
            default: return f
          }
        })
        setFields(updatedFields)
        setPendingFields([])
        setStatus("treated") //NOUVEAU: TREATED après OCR
        setTimeout(checkWarnings, 100)
        toast.dismiss(loadingToast)
        toast.success("OCR terminé")
        return
      }

      console.log("Extraction pour Facture ID:", invoice.id, "Template:", forcedTemplateId || invoice.templateId)
      console.log("Extraction pour Facture ID:", invoice.id)
      const result = await api.processInvoice(invoice.id)

      console.log("=== DYNAMIC OCR RESULT (V2) ===")
      console.log("Template:", result.templateName)
      console.log("Status:", result.status)
      console.log("Confidence:", result.overallConfidence)
      console.log("===============================")

      // Si Result n'a pas le texte OCR, on garde l'ancien texte s'il existe
      const newText = result.rawOcrText || result.extractedText
      if (newText) {
        setExtractedText(newText)
      }

      // Mettre à jour les alertes techniques
      setMissingFields(result.missingFields || [])
      setLowConfidenceFields(result.lowConfidenceFields || [])
      setOverallConfidence(result.overallConfidence)
      setExtractionMethod(result.extractionMethod || (result.templateId ? "DYNAMIC_TEMPLATE" : "PATTERNS"))
      setTemplateDetected(!!result.templateId)

      const normalizedStatus = normalizeStatus(result.status || "treated")
      setStatus(normalizedStatus)

      if (result.fieldsData) {
        const updatedFields = ParseBackendFieldsData(result.fieldsData, fields, result, newText)
        setFields(updatedFields)
      }

      toast.dismiss(loadingToast)

      if (result.templateId) {
        const confidenceStr = result.overallConfidence !== undefined
          ? `\nConfiance: ${(result.overallConfidence * 100).toFixed(0)}%`
          : "";

        toast.success(
          `Template "${result.templateName}" appliqué${confidenceStr}`,
          { duration: 4000 }
        )
      } else {
        toast.success("Extraction dynamique terminée", { duration: 3000 })
      }


      setTimeout(checkWarnings, 100)

    } catch (err: any) {
      console.error("OCR Extraction Error:", err)
      toast.dismiss(loadingToast)
      const errorMessage = err instanceof Error ? err.message : "Erreur lors de l'extraction OCR"

      if (errorMessage.toLowerCase().includes("non trouvée")) {
        toast.error("Facture introuvable sur le serveur. Veuillez rafraîchir la liste.", {
          action: {
            label: "Retour",
            onClick: () => onBack()
          },
          duration: 5000
        })
      } else {
        toast.error(errorMessage)
      }
      setStatus("error")
    } finally {
      setIsProcessingOcr(false)
    }
  }

  const updateFieldValue = (key: string, value: string) => {
    setFields((prev) => prev.map((f) => (f.key === key ? { ...f, value } : f)))
    setPendingFields((prev) => prev.filter((f) => f !== key))
    setWarnings((prev) => prev.filter((w) => w.field !== key))

    if (key === "amountHT" || key === "tva" || key === "amountTTC") {
      setTimeout(() => {
        const ht = Number.parseFloat(
          key === "amountHT" ? value : String(fields.find((f) => f.key === "amountHT")?.value || "0"),
        )
        const tva = Number.parseFloat(key === "tva" ? value : String(fields.find((f) => f.key === "tva")?.value || "0"))

        if (key === "amountHT" && ht > 0) {
          const newTva = ht * 0.2
          const newTtc = ht + newTva
          setFields((prev) =>
            prev.map((f) => {
              if (f.key === "tva") return { ...f, value: newTva.toFixed(2) }
              if (f.key === "amountTTC") return { ...f, value: newTtc.toFixed(2) }
              return f
            }),
          )
        }
      }, 500)
    }
  }

  const updateTierField = (key: keyof Tier, value: string) => {
    setTier(prev => {
      if (!prev) {
        return {
          id: 0,
          libelle: "Fournisseur manuel",
          supplierAccount: key === 'supplierAccount' ? value : "",
          defaultChargeAccount: key === 'defaultChargeAccount' ? value : "",
          tvaAccount: key === 'tvaAccount' ? value : "",
          active: true,
          hasAccountingConfig: true,
          [key]: value
        } as Tier
      }
      return { ...prev, [key]: value }
    })
  }

  // NOUVEAU: Synchronisation de la sélection native avec le champ actif
  useEffect(() => {
    const handleMouseUpSelection = () => {
      // Si on est en train de dessiner un rectangle, on ne veut pas interférer avec la sélection de texte
      if (isDrawing) return

      const selection = window.getSelection()?.toString().trim()
      if (!selection) return

      // --- NOUVEAU: Logique de capture spécifique au mode ---
      if (isSelectingPosition) {
        const fieldKey = isSelectingPosition
        if (selectionMode === 'PATTERN') {
          // Mode PATTERN : Capturer le texte comme pattern d'ancrage
          setFieldPatterns(prev => ({ ...prev, [fieldKey]: selection }))
          toast.success(`Pattern enregistré : "${selection}"`)
          setIsSelectingPosition(null) // Terminer le mode sélection après clic
        } else {
          // Mode VALUE : Capture de la valeur textuelle (clic simple sans dessin rectangle)
          updateFieldValue(fieldKey, selection)
          toast.success(`Valeur capturée : "${selection}"`)
          setIsSelectingPosition(null)
        }
      } else if (focusedFieldKey) {
        // Mode passif (juste un champ focalisé dans le formulaire)
        // Cas 1: Champ standard ou personnalisé
        const standardField = allFields.find(f => f.key === focusedFieldKey)
        if (standardField) {
          updateFieldValue(focusedFieldKey, selection)
          toast.success(`Valeur capturée : ${selection.length > 20 ? selection.substring(0, 20) + "..." : selection}`)
        } else if (focusedFieldKey.startsWith("tier_")) {
          // Cas 2: Champ Tier (comptabilité) - prefixé pour identification
          const tierKey = focusedFieldKey.replace("tier_", "") as keyof Tier
          updateTierField(tierKey, selection)
          toast.success(`Compte mis à jour : ${selection}`)
        }
      }
    }

    document.addEventListener("mouseup", handleMouseUpSelection)
    return () => document.removeEventListener("mouseup", handleMouseUpSelection)
  }, [focusedFieldKey, isSelectingPosition, selectionMode, isDrawing, updateFieldValue])

  const updateCustomFieldValue = (key: string, value: string) => {
    setCustomFields((prev) => prev.map((f) => (f.key === key ? { ...f, value } : f)))
  }

  // NOUVELLE fonction clearFieldValue - AJOUTEZ-LA
  const clearFieldValue = (key: string) => {
    setFields((prev) => prev.map((f) =>
      f.key === key
        ? { ...f, value: "", detected: false, position: undefined }
        : f
    ))
    setPendingFields((prev) => prev.filter((f) => f !== key))
    setWarnings((prev) => prev.filter((w) => w.field !== key))
    toast.info(`Champ "${fields.find(f => f.key === key)?.label}" vidé`)
  }

  // NOUVELLE fonction pour les champs personnalisés
  const clearCustomFieldValue = (key: string) => {
    setCustomFields((prev) => prev.map((f) =>
      f.key === key
        ? { ...f, value: "", detected: false, position: undefined }
        : f
    ))
    toast.info(`Champ personnalisé vidé`)
  }

  const applySuggestion = (warning: Warning) => {
    if (warning.suggestion) {
      updateFieldValue(warning.field, warning.suggestion)
    }
  }

  const startSelection = (key: string, mode: 'VALUE' | 'PATTERN' = 'VALUE') => {
    setIsSelectingPosition(key)
    setSelectionMode(mode)
    setSelectionBox(null)
    setSelectedFieldKey(key)
    toast.info(mode === 'PATTERN' ? "Sélectionnez le pattern (label) dans le document" : "Sélectionnez la valeur dans le document")
  }

  const cancelPositionSelection = () => {
    setIsSelectingPosition(null)
    setSelectionBox(null)
    setIsDrawing(false)
    setSelectedFieldKey(null)
  }

  // Manual extraction features removed as they are not supported by the new backend controllers

  const addCustomField = () => {
    if (!newFieldLabel.trim()) return

    const key = `custom_${Date.now()}`
    setCustomFields((prev) => [
      ...prev,
      {
        key,
        label: newFieldLabel,
        value: "",
        type: "text",
      },
    ])
    setNewFieldLabel("")
    setShowAddField(false)
  }

  const removeCustomField = (key: string) => {
    setCustomFields((prev) => prev.filter((f) => f.key !== key))
  }

  const handleSave = async () => {
    setIsSaving(true)

    try {
      // 1. Préparer les données pour le backend (V2 attend un Map<String, String>)
      const fieldsForBackend: Record<string, string> = {}

        ;[...fields, ...customFields].forEach((field) => {
          fieldsForBackend[field.key] = String(field.value || "")
        })

      // 2. Pour le Wizard et le state local, on garde la structure complète
      const updatedInvoice: LocalInvoice = {
        ...invoice,
        fields: [...fields, ...customFields],
        extractedText,
        status: status === "validated" ? "validated" : "ready_to_validate",
      }

      console.log("💾 handleSave called - isDemoMode:", isDemoMode);

      if (!isDemoMode) {
        console.log("📤 Sending fields to backend:", fieldsForBackend)
        // Enregistrer les champs (V2)
        const savedInvoice = await api.updateDynamicFields(invoice.id, fieldsForBackend)
        console.log("✅ Facture dynamique enregistrée:", savedInvoice)

        // Mettre à jour l'état local avec les métadonnées V2 (confiance, champs manquants)
        if (savedInvoice.missingFields) setMissingFields(savedInvoice.missingFields)
        if (savedInvoice.lowConfidenceFields) setLowConfidenceFields(savedInvoice.lowConfidenceFields)
        if (savedInvoice.overallConfidence) setOverallConfidence(savedInvoice.overallConfidence)

        // Mettre à jour le statut (devient READY_TO_VALIDATE)
        const normalizedStatus = normalizeStatus(savedInvoice.status)
        setStatus(normalizedStatus)

        if (canCreateTemplate && !templateDetected) {
          console.log("Ouverture du Wizard de template (Nouveau fournisseur détecté)")
          setIsCreatingTemplate(true)
          toast.info("Nouveau fournisseur détecté : configurez votre template", {
            duration: 5000
          })
        }
      }

      // 4. Notifier le parent du changement
      onSave(updatedInvoice)
    } catch (err) {
      console.error("Save failed:", err)
      toast.error("Erreur lors de la sauvegarde")
    } finally {
      setIsSaving(false)
    }
  }

  const handleValidate = async () => {
    if (status !== "ready_to_validate") {
      toast.error("Veuillez d'abord enregistrer les données")
      return
    }

    setIsValidating(true)

    try {
      if (!isDemoMode) {
        await api.validateDynamicInvoice(invoice.id)
      } else {
        await new Promise((resolve) => setTimeout(resolve, 500))
      }

      setStatus("validated")


      const updatedInvoice: LocalInvoice = {
        ...invoice,
        fields: [...fields, ...customFields],
        extractedText,
        status: "validated",
      }

      onSave(updatedInvoice)

      toast.success("Facture validée avec succès")

    } catch (err) {
      console.error("Validation failed:", err)
      const errorMessage = err instanceof Error ? err.message : "Erreur inconnue"
      toast.error(`Erreur lors de la validation: ${errorMessage}`)
    } finally {
      setIsValidating(false)
    }
  }

  // --- NOUVEAUX HANDLERS POUR LA SÉLECTION MANUELLE ---
  const handleMouseDown = (e: React.MouseEvent) => {
    // Désactiver le dessin de rectangle si on est en mode PATTERN (on veut la sélection native)
    if (!isSelectingPosition || selectionMode === 'PATTERN' || !imageContainerRef.current) return

    // Désactiver la sélection de texte seulement pendant le dessin de rectangle
    e.preventDefault()

    const rect = imageContainerRef.current.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100

    setSelectionBox({ startX: x, startY: y, endX: x, endY: y })
    setIsDrawing(true)
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDrawing || !selectionBox || !imageContainerRef.current) return

    const rect = imageContainerRef.current.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100

    setSelectionBox(prev => prev ? { ...prev, endX: x, endY: y } : null)
  }

  const handleMouseUp = () => {
    if (!isDrawing || !selectionBox) return

    setIsDrawing(false)

    // Calcul de la zone finale
    const minX = Math.min(selectionBox.startX, selectionBox.endX)
    const minY = Math.min(selectionBox.startY, selectionBox.endY)
    const width = Math.abs(selectionBox.endX - selectionBox.startX)
    const height = Math.abs(selectionBox.endY - selectionBox.startY)

    // Seulement si la zone est significative
    if (width > 0.1 && height > 0.1) {
      const newPosition = { x: minX, y: minY, width, height }

      // Récupérer la sélection de texte faite PENDANT le dessin
      const selection = window.getSelection()?.toString().trim()
      const fieldKey = isSelectingPosition!
      const fieldLabel = allFields.find(f => f.key === fieldKey)?.label

      if (selectionMode === 'PATTERN') {
        // --- MODE PATTERN : On enregistre seulement le texte comme pattern d'ancrage ---
        if (selection) {
          setFieldPatterns(prev => ({ ...prev, [fieldKey]: selection }))
          toast.success(`Pattern enregistré pour ${fieldLabel} : "${selection}"`)
        } else {
          toast.warning("Aucun texte sélectionné pour le pattern")
        }
      } else {
        // --- MODE VALUE : On enregistre la position ET la valeur (recherche rectangle + texte) ---
        // Mettre à jour le champ en cours de sélection
        setFields(prev => prev.map(f =>
          f.key === fieldKey
            ? {
              ...f,
              position: newPosition,
              detected: true,
              value: selection || f.value // Remplir la valeur si du texte est sélectionné
            }
            : f
        ))

        setCustomFields(prev => prev.map(f =>
          f.key === fieldKey
            ? {
              ...f,
              position: newPosition,
              detected: true,
              value: selection || f.value // Remplir la valeur si du texte est sélectionné
            }
            : f
        ))

        if (selection) {
          toast.success(`Valeur et position enregistrées pour ${fieldLabel} : "${selection}"`)
        } else {
          toast.success(`Position enregistrée pour ${fieldLabel}`)
        }
      }
    }

    setSelectionBox(null)
    setIsSelectingPosition(null)
  }
  // --------------------------------------------------

  const getSelectionBoxStyle = () => {
    if (!selectionBox) return {}
    const minX = Math.min(selectionBox.startX, selectionBox.endX)
    const minY = Math.min(selectionBox.startY, selectionBox.endY)
    const width = Math.abs(selectionBox.endX - selectionBox.startX)
    const height = Math.abs(selectionBox.endY - selectionBox.startY)
    return {
      left: `${minX}%`,
      top: `${minY}%`,
      width: `${width}%`,
      height: `${height}%`,
    }
  }

  const isValidated = status === "validated"

  // Fonction pour rendre la carte d'informations Tier
  // const renderTierCard = () => {
  //   if (!tier) return null

  //   return (
  //     <Card className="border-blue-500/20 bg-blue-50/50 dark:bg-blue-950/20">
  //       <CardHeader className="pb-3">
  //         <div className="flex items-center justify-between">
  //           <CardTitle className="text-base flex items-center gap-2">
  //             <Building2 className="h-4 w-4 text-blue-600" />
  //             Fournisseur Identifié
  //           </CardTitle>
  //           <Badge variant={tier.hasAccountingConfig ? "default" : "secondary"}>
  //             {tier.hasAccountingConfig ? "Comptes configurés" : "Configuration requise"}
  //           </Badge>
  //         </div>
  //       </CardHeader>
  //       <CardContent className="space-y-3">
  //         <div className="grid grid-cols-2 gap-3 text-sm">
  //           <div>
  //             <span className="text-muted-foreground text-xs">Libellé:</span>
  //             <p className="font-medium">{tier.libelle}</p>
  //           </div>
  //           <div>
  //             <span className="text-muted-foreground text-xs">N° Tier:</span>
  //             <p className="font-medium font-mono text-xs">{tier.nTier || "N/A"}</p>
  //           </div>
  //           <div>
  //             <span className="text-muted-foreground text-xs">ICE:</span>
  //             <p className="font-mono text-xs">{tier.ice || "N/A"}</p>
  //           </div>
  //           <div>
  //             <span className="text-muted-foreground text-xs">IF:</span>
  //             <p className="font-mono text-xs">{tier.ifNumber || "N/A"}</p>
  //           </div>
  //         </div>

  //         {tier.hasAccountingConfig && (
  //           <div className="pt-2 border-t">
  //             <p className="text-xs text-muted-foreground mb-2">Comptes comptables:</p>
  //             <div className="grid grid-cols-3 gap-2 text-xs">
  //               <div>
  //                 <span className="text-muted-foreground">Frs:</span>
  //                 <p className="font-mono font-medium">{tier.supplierAccount}</p>
  //               </div>
  //               <div>
  //                 <span className="text-muted-foreground">Charge:</span>
  //                 <p className="font-mono font-medium">{tier.defaultChargeAccount || "N/A"}</p>
  //               </div>
  //               <div>
  //                 <span className="text-muted-foreground">TVA:</span>
  //                 <p className="font-mono font-medium">{tier.tvaAccount || "N/A"}</p>
  //               </div>
  //             </div>
  //           </div>
  //         )}

  //         {!tier.hasAccountingConfig && (
  //           <p className="text-xs text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/20 p-2 rounded">
  //             ⚠️ Les comptes comptables doivent être configurés manuellement pour ce fournisseur
  //           </p>
  //         )}
  //       </CardContent>
  //     </Card>
  //   )
  // }

  // Fonction pour rendre une carte de champ OCR (avec boutons de sélection)
  const renderFieldCard = (field: InvoiceField | undefined, isCustom: boolean = false) => {
    if (!field) return null

    const isPending = pendingFields.includes(field.key)
    const hasWarning = warnings.some((w) => w.field === field.key)

    return (
      <Card key={field.key} className="shadow-sm hover:shadow-md transition-shadow">
        <CardContent className="p-2 space-y-1.5">
          {/* Header avec label et badges */}
          <div className="flex items-center justify-between">
            <Label
              htmlFor={field.key}
              className={`text-sm font-medium flex items-center gap-2 ${isPending ? "text-amber-500" : ""}`}
            >
              {field.label}
              {isCustom && <Badge variant="outline" className="text-xs">Personnalisé</Badge>}
              {invoice.autoFilledFields?.includes(field.key) && (
                <Badge className="text-[10px] px-1.5 py-0.5 bg-green-500 text-white">
                  <Sparkles className="h-2 w-2 mr-1" />
                  Auto
                </Badge>
              )}
              {field.detected && <CheckCircle className="h-3 w-3 text-green-500" />}
              {isPending && <AlertTriangle className="h-3 w-3 text-amber-500" />}
              {field.confidence !== undefined && field.confidence !== null && (
                <ConfidenceBadge score={field.confidence} size="sm" showPercentage={true} showIcon={false} />
              )}
            </Label>

            {/* Boutons d'action */}
            <div className="flex items-center gap-1">
              {isSelectingPosition === field.key ? (
                <Button
                  size="sm"
                  variant="ghost"
                  className={`h-7 px-2 text-xs animate-pulse ${selectionMode === 'PATTERN'
                    ? "bg-blue-100 text-blue-700 hover:bg-blue-200"
                    : "bg-emerald-100 text-emerald-700 hover:bg-emerald-200"
                    }`}
                  onClick={cancelPositionSelection}
                  title="Annuler la sélection"
                >
                  <X className="h-3 w-3 mr-1" />
                  {selectionMode === 'PATTERN' ? 'Ancrage' : 'Valeur'}
                </Button>
              ) : (
                <>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 px-2 text-xs hover:bg-blue-50 text-blue-600"
                    onClick={() => startSelection(field.key, 'PATTERN')}
                    title="Détecter pattern (ancrage)"
                  >
                    <Scan className="h-3 w-3" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 px-2 text-xs hover:bg-emerald-50 text-emerald-600"
                    onClick={() => startSelection(field.key, 'VALUE')}
                    title="Détecter valeur"
                  >
                    <Target className="h-3 w-3" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 px-2 text-xs text-amber-600 hover:text-amber-700 hover:bg-amber-100"
                    onClick={() => isCustom ? clearCustomFieldValue(field.key) : clearFieldValue(field.key)}
                    title="Vider la valeur"
                    disabled={!field.value || String(field.value).trim() === ""}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                  {isCustom && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 px-2 text-xs text-destructive hover:text-destructive hover:bg-red-50"
                      onClick={() => removeCustomField(field.key)}
                      title="Supprimer le champ personnalisé"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  )}
                </>
              )}
            </div>
          </div>

          {/* Badge Pattern */}
          {fieldPatterns[field.key] && (
            <Badge
              variant="outline"
              className="text-xs px-2 py-1 bg-blue-50 text-blue-700 border-blue-200 cursor-pointer hover:bg-blue-100"
              onClick={() => {
                setFieldPatterns(prev => {
                  const newPatterns = { ...prev }
                  delete newPatterns[field.key]
                  return newPatterns
                })
                toast.info("Pattern supprimé")
              }}
              title="Cliquer pour supprimer le pattern"
            >
              Pattern: {fieldPatterns[field.key].length > 20 ? fieldPatterns[field.key].substring(0, 20) + "..." : fieldPatterns[field.key]} ✕
            </Badge>
          )}

          {/* Label descriptif */}
          <p className="text-xs text-muted-foreground font-medium">Valeur extraite</p>

          {/* Input */}
          <Input
            id={field.key}
            value={String(field.value || "")}
            onChange={(e) => updateFieldValue(field.key, e.target.value)}
            className={`bg-white transition-all ${isPending || lowConfidenceFields.includes(field.key) ? "border-amber-500 bg-amber-50/10" : ""
              } ${hasWarning ? "border-red-500" : ""} ${selectedFieldKey === field.key ? "ring-2 ring-primary border-primary" : ""
              }`}
            disabled={status === "validated"}
            onFocus={() => {
              setSelectedFieldKey(field.key)
              setFocusedFieldKey(field.key)
            }}
            onBlur={() => {
              setTimeout(() => {
                setSelectedFieldKey(null)
                setFocusedFieldKey(null)
              }, 200)
            }}
          />

          {/* Position debug info */}
          {field.position && (
            <div className="text-[10px] text-muted-foreground font-mono bg-muted/30 px-2 py-1 rounded">
              x: {field.position.x.toFixed(1)}% | y: {field.position.y.toFixed(1)}% | w: {field.position.width.toFixed(1)}% | h: {field.position.height.toFixed(1)}%
            </div>
          )}
        </CardContent>
      </Card>
    )
  }

  // Fonction pour rendre une carte de champ comptable (avec auto-remplissage depuis Tier)
  const renderAccountFieldCard = (key: string, label: string, tierFieldName?: keyof Tier) => {
    // Récupérer la valeur depuis le Tier si disponible
    const tierValue = tier && tierFieldName ? tier[tierFieldName] : null
    const hasValue = tierValue !== null && tierValue !== undefined && tierValue !== ""
    const isAutoFilled = hasValue && tier?.hasAccountingConfig

    return (
      <Card key={key} className="shadow-sm hover:shadow-md transition-shadow">
        <CardContent className="p-2 space-y-1.5">
          {/* Header avec label et badges */}
          <div className="flex items-center justify-between">
            <Label
              htmlFor={key}
              className="text-sm font-medium flex items-center gap-2"
            >
              {label}
              <Badge variant="outline" className="text-xs bg-purple-50 text-purple-700 border-purple-200">
                Comptable
              </Badge>
              {isAutoFilled && (
                <Badge className="text-[10px] px-1.5 py-0.5 bg-blue-500 text-white">
                  <Building2 className="h-2 w-2 mr-1" />
                  Tier
                </Badge>
              )}
            </Label>
          </div>

          {/* Label descriptif */}
          <p className="text-xs text-muted-foreground font-medium">Numéro de compte</p>

          {/* Input */}
          <Input
            id={`tier_${key}`} // Prefixé pour identification dans handleMouseUpSelection
            value={tierValue?.toString() || ""}
            onChange={(e) => updateTierField(tierFieldName as keyof Tier, e.target.value)}
            className="bg-white"
            placeholder={hasValue ? "" : "Ex: 401000"}
            disabled={status === "validated"}
            onFocus={() => setFocusedFieldKey(`tier_${key}`)}
            onBlur={() => setTimeout(() => setFocusedFieldKey(null), 200)}
          />

          {/* Note explicative */}

        </CardContent>
      </Card>
    )
  }

  return (
    <div className="min-h-screen bg-background p-6">
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-xl font-bold text-foreground">
                Facture #{String(fields.find((f) => f.key === "invoiceNumber")?.value || invoice.filename)}
              </h1>
              {getStatusBadge()}
              {overallConfidence !== undefined && (
                <div className="flex items-center gap-1">
                  <span className="text-[10px] text-muted-foreground uppercase font-bold ml-1">Analyse:</span>
                  <ConfidenceBadge score={overallConfidence * 100} showPercentage={true} showIcon={false} size="sm" />
                </div>
              )}
              {templateDetected ? (
                <Badge variant="outline" className="gap-1 text-emerald-600 border-emerald-200 bg-emerald-50">
                  <Target className="h-3 w-3" />
                  Template: {invoice.templateName || "Détecté"}
                </Badge>
              ) : (
                <Badge variant="outline" className="gap-1 text-muted-foreground border-muted-foreground/20 bg-muted/50">
                  Sans template
                </Badge>
              )}
            </div>

            <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
              <span>Upload: {formatDate(invoice.createdAt)}</span>
              <span>Fichier: {invoice.filename}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">

          {/* Bouton Reprocesser OCR */}
          <Button
            variant="outline"
            className="gap-2 bg-transparent"
            onClick={() => handleOcrExtract()}
            disabled={isProcessingOcr}
          >
            {isProcessingOcr ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Analyse...
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4" />
                Reprocesser OCR
              </>
            )}
          </Button>

          {/* Bouton Enregistrer */}
          <Button
            variant="outline"
            className="gap-2 bg-transparent"
            onClick={() => {
              const updatedInvoice: LocalInvoice = {
                ...invoice,
                fields: allFields,
                status,
                pendingFields,
                missingFields,
                lowConfidenceFields,
                overallConfidence,
              }
              onSave(updatedInvoice)
              toast.success("Facture enregistrée")
            }}
            disabled={isSaving}
          >
            {isSaving ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Enregistrement...
              </>
            ) : (
              <>
                <Save className="h-4 w-4" />
                Enregistrer
              </>
            )}
          </Button>

          {/* Bouton Valider */}
          <Button
            className="gap-2"
            onClick={() => {
              setIsValidating(true)
              const updatedInvoice: LocalInvoice = {
                ...invoice,
                fields: allFields,
                status: "validated",
                pendingFields: [],
                missingFields: [],
                lowConfidenceFields: [],
                overallConfidence,
              }
              onSave(updatedInvoice)
              setStatus("validated")
              setIsValidating(false)
              toast.success("Facture validée avec succès")
            }}
            disabled={isValidating || status === "validated"}
          >
            {isValidating ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Validation...
              </>
            ) : (
              <>
                <CheckCircle className="h-4 w-4" />
                Valider
              </>
            )}
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Document Viewer */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">Visualiseur de document</CardTitle>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8 bg-transparent"
                  onClick={() => setZoom((z) => Math.max(50, z - 25))}
                >
                  <ZoomOut className="h-4 w-4" />
                </Button>
                <span className="text-sm text-muted-foreground w-12 text-center">{zoom}%</span>
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8 bg-transparent"
                  onClick={() => setZoom((z) => Math.min(200, z + 25))}
                >
                  <ZoomIn className="h-4 w-4" />
                </Button>
                {documentUrl && (
                  <Button variant="outline" size="icon" className="h-8 w-8 bg-transparent" asChild>
                    <a href={documentUrl} download={invoice.filename}>
                      <Download className="h-4 w-4" />
                    </a>
                  </Button>
                )}
              </div>
            </div>
            {isSelectingPosition && (
              <p className="text-sm text-primary mt-2">
                {selectionMode === 'PATTERN'
                  ? `Sélectionnez la zone du PATTERN (Label) pour "${allFields.find(f => f.key === isSelectingPosition)?.label}"`
                  : `Sélectionnez la VALEUR pour "${allFields.find(f => f.key === isSelectingPosition)?.label}"`
                }
              </p>
            )}
          </CardHeader>
          <CardContent>
            <div className="overflow-auto rounded-lg border border-border">
              {isLoadingDocument && (
                <div className="flex aspect-[3/4] items-center justify-center bg-muted">
                  <div className="text-center">
                    <Loader2 className="mx-auto h-12 w-12 text-muted-foreground animate-spin" />
                    <p className="mt-4 text-sm text-muted-foreground">Chargement du document...</p>
                  </div>
                </div>
              )}

              {!isLoadingDocument && documentError && (
                <div className="flex aspect-[3/4] items-center justify-center bg-muted">
                  <div className="text-center">
                    <AlertTriangle className="mx-auto h-16 w-16 text-amber-500" />
                    <p className="mt-4 text-sm text-muted-foreground">{documentError}</p>
                  </div>
                </div>
              )}

              {!isLoadingDocument && !documentError && documentUrl && (
                <div
                  ref={imageContainerRef}
                  onMouseDown={handleMouseDown}
                  onMouseMove={handleMouseMove}
                  onMouseUp={handleMouseUp}
                  className={`relative transition-transform origin-top-left ${isSelectingPosition && selectionMode === 'VALUE'
                    ? "cursor-crosshair"
                    : isSelectingPosition
                      ? "cursor-text"
                      : ""
                    } select-text
                    }`}
                  style={{ transform: `scale(${zoom / 100})`, transformOrigin: "top left" }}
                >
                  {/* Affichage IMAGE */}
                  {isImage && (
                    <div className="relative">
                      <img
                        src={documentUrl}
                        alt="Document"
                        className="w-full"
                        draggable={false}
                        onLoad={() => setDocumentRendered(true)}
                        onError={() => setDocumentError("Impossible de charger l'image")}
                      />
                      {/* Calque de texte transparent pour images */}
                      {allFields.filter(f => f.position).map(field => (
                        <span
                          key={`text-${field.key}`}
                          className="absolute select-text text-transparent outline-none cursor-text transition-colors hover:bg-primary/5 hover:text-primary/10"
                          style={{
                            left: `${field.position!.x}%`,
                            top: `${field.position!.y}%`,
                            width: `${field.position!.width}%`,
                            height: `${field.position!.height}%`,
                            zIndex: 2,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: 'min(12px, 2cqh)', // Dynamic font size attempt
                          }}
                        >
                          {String(field.value || "")}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Affichage PDF - UNE SEULE PAGE */}
                  {isPdf && (
                    <Document
                      file={documentUrl}
                      onLoadSuccess={({ numPages }) => {
                        console.log("PDF loaded successfully, pages:", numPages)
                        setNumPages(numPages)
                        setDocumentRendered(true)
                      }}
                      onLoadError={(error) => {
                        console.error("Erreur PDF:", error)
                        setDocumentError("Impossible de charger le PDF: " + (error.message || "Erreur inconnue"))
                      }}
                      loading={
                        <div className="flex items-center justify-center h-[600px]">
                          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                        </div>
                      }
                    >
                      {documentRendered && (
                        <Page
                          key={`page-${pageNumber}-${zoom}`}
                          pageNumber={pageNumber}
                          renderTextLayer={true} // Obligatoire pour la sélection
                          renderAnnotationLayer={false}
                          width={imageContainerRef.current?.clientWidth || 800}
                          onLoadError={(error) => console.error("Page load error:", error)}
                        />
                      )}
                    </Document>
                  )}

                  {/* Rectangles de sélection CLIQUABLES */}
                  {documentRendered && allFields
                    .filter((f) => f.position && (!isSelectingPosition || f.key !== isSelectingPosition))
                    .map((field) => {
                      const isSelected = selectedFieldKey === field.key
                      const isFocused = focusedFieldKey === field.key
                      const hasValue = field.value && String(field.value).trim() !== ""
                      const confidence = field.confidence || 0
                      const isEstimated = field.hasEstimatedPosition

                      // SMART VISUAL FEEDBACK - Code Couleur Base sur la Confiance et la Source
                      let statusColors = {
                        border: "border-violet-500",
                        bg: "bg-violet-500/10",
                        hover: "hover:bg-violet-500/20 hover:border-violet-500",
                        isDashed: false
                      }

                      if (isFocused) {
                        statusColors = {
                          border: "border-emerald-500",
                          bg: "bg-emerald-500/30",
                          hover: "hover:bg-emerald-500/40",
                          isDashed: false
                        }
                      } else if (isSelected) {
                        statusColors = {
                          border: "border-violet-500",
                          bg: "bg-violet-500/30",
                          hover: "hover:bg-violet-500/40",
                          isDashed: false
                        }
                      } else if (isEstimated) {
                        statusColors = {
                          border: "border-amber-400",
                          bg: "bg-amber-400/5",
                          hover: "hover:bg-amber-400/15 hover:border-amber-400",
                          isDashed: true
                        }
                      } else if (confidence >= 0.8) {
                        statusColors = {
                          border: "border-green-500",
                          bg: "bg-green-500/10",
                          hover: "hover:bg-green-500/20 hover:border-green-500",
                          isDashed: false
                        }
                      } else if (confidence >= 0.4) {
                        statusColors = {
                          border: "border-blue-500",
                          bg: "bg-blue-500/10",
                          hover: "hover:bg-blue-500/20 hover:border-blue-500",
                          isDashed: false
                        }
                      } else {
                        statusColors = {
                          border: "border-amber-500",
                          bg: "bg-amber-500/5",
                          hover: "hover:bg-amber-500/15 hover:border-amber-500",
                          isDashed: true
                        }
                      }

                      return (
                        <div
                          key={field.key}
                          style={{
                            left: `${field.position!.x}%`,
                            top: `${field.position!.y}%`,
                            width: `${field.position!.width}%`,
                            height: `${field.position!.height}%`,
                            zIndex: isSelected || isFocused ? 20 : 10,
                            pointerEvents: "none",
                          }}
                          className={`absolute border-2 transition-all ${statusColors.isDashed ? "border-dashed" : "border-solid"
                            } ${statusColors.border} ${statusColors.bg} ${statusColors.hover} ${isSelected || isFocused ? "shadow-lg scale-[1.01]" : ""
                            }`}
                          title={`${field.label}${hasValue ? `: ${field.value}` : ""}${isEstimated ? " (Position estimée)" : ""}`}
                        >
                          {/* Label cliquable pour focus - Seul lui intercepte les clics */}
                          <button
                            type="button"
                            style={{ pointerEvents: "auto" }}
                            className={`absolute -top-6 left-0 text-[10px] px-1.5 py-0.5 rounded shadow-sm whitespace-nowrap transition-all hover:scale-105 active:scale-95 ${isSelected || isFocused
                              ? "bg-primary text-primary-foreground font-semibold ring-2 ring-primary/20"
                              : isEstimated
                                ? "bg-amber-500 text-white"
                                : "bg-primary/90 text-primary-foreground hover:bg-primary"
                              }`}
                            onClick={(e) => {
                              e.stopPropagation()
                              setSelectedFieldKey(field.key)
                              setFocusedFieldKey(field.key)

                              // Scroll vers le champ
                              const element = document.getElementById(field.key)
                              if (element) {
                                element.scrollIntoView({ behavior: 'smooth', block: 'center' })
                                element.focus()
                              }

                              toast.info(`Champ: ${field.label}${hasValue ? ` (Valeur: ${field.value})` : ""}`, {
                                description: isEstimated
                                  ? "Position estimée via recherche textuelle"
                                  : `Confiance: ${Math.round(confidence * 100)}%`
                              })
                            }}
                          >
                            <span className="flex items-center gap-1">
                              {(isSelected || isFocused) && <Target className="h-2 w-2" />}
                              {field.label}
                              {isEstimated && <span className="ml-1 opacity-70 text-[8px] font-normal italic">(estimé)</span>}
                              {hasValue && (
                                <span className="ml-1 opacity-80 border-l border-white/20 pl-1 text-[9px]">
                                  {String(field.value).length > 12
                                    ? String(field.value).substring(0, 12) + "..."
                                    : field.value}
                                </span>
                              )}
                            </span>
                          </button>
                        </div>
                      )
                    })}

                  {/* Rectangle en cours de dessin */}
                  {isDrawing && selectionBox && (
                    <div
                      className="absolute border-2 border-dashed border-primary bg-primary/20"
                      style={getSelectionBoxStyle()}
                    />
                  )}
                </div>
              )}
            </div>

            {/* Navigation pages PDF */}
            {isPdf && numPages > 1 && (
              <div className="flex items-center justify-center gap-2 mt-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPageNumber(p => Math.max(1, p - 1))}
                  disabled={pageNumber === 1}
                >
                  Précédent
                </Button>
                <span className="text-sm">
                  Page {pageNumber} / {numPages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPageNumber(p => Math.min(numPages, p + 1))}
                  disabled={pageNumber === numPages}
                >
                  Suivant
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Extraction Form */}
        <div className="space-y-4">
          {/* Warnings */}
          {warnings.length > 0 && (
            <Card className="border-amber-500/50 bg-amber-500/10">
              <CardContent className="pt-4">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5" />
                  <div className="flex-1 space-y-2">
                    {warnings.map((warning, idx) => (
                      <div key={idx} className="flex items-center justify-between">
                        <p className="text-sm text-amber-700 dark:text-amber-300">{warning.message}</p>
                        {warning.suggestion && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 text-xs gap-1 bg-transparent"
                            onClick={() => applySuggestion(warning)}
                          >
                            <Lightbulb className="h-3 w-3" />
                            Appliquer: {warning.suggestion} DH
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Template Detection Banner */}
          {invoice.templateDetected && invoice.templateName && (
            <Card className="border-green-500/50 bg-green-50 dark:bg-green-950/20">
              <CardContent className="pt-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5" />
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-green-900 dark:text-green-100">
                          Template détecté
                        </p>
                        <p className="text-sm text-green-700 dark:text-green-300 mt-1">
                          {invoice.templateName}
                          {invoice.templateVersion && ` (v${invoice.templateVersion})`}
                        </p>
                      </div>
                      <Badge className="bg-green-600 text-white">
                        {invoice.extractionMethod === "DYNAMIC_TEMPLATE" ? "Extraction Dynamique" : "Patterns"}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Overall Confidence */}
          {invoice.overallConfidence !== undefined && invoice.overallConfidence !== null && (
            <Card>
              <CardContent className="pt-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Confiance globale</Label>
                    <ConfidenceBadge score={invoice.overallConfidence} size="md" />
                  </div>
                  <Progress value={invoice.overallConfidence} className="h-2" />
                  {invoice.averageConfidence !== undefined && (
                    <p className="text-xs text-muted-foreground">
                      Moyenne par champ: {Math.round(invoice.averageConfidence)}%
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Missing Fields Alert */}
          {missingFields.length > 0 && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Champs requis manquants</AlertTitle>
              <AlertDescription>
                Les champs suivants n'ont pas été détectés : {missingFields.join(", ")}
              </AlertDescription>
            </Alert>
          )}

          {/* Low Confidence Fields Alert */}
          {lowConfidenceFields.length > 0 && (
            <Alert className="border-amber-500/50 bg-amber-50 dark:bg-amber-950/20">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              <AlertTitle className="text-amber-900 dark:text-amber-100">
                Attention - Analyse incertaine
              </AlertTitle>
              <AlertDescription className="text-amber-700 dark:text-amber-300">
                Vérifiez ces champs (confiance faible) : {lowConfidenceFields.join(", ")}
              </AlertDescription>
            </Alert>
          )}

          {/* Tier Information Card */}
          {/* {renderTierCard()} */}

          {/* Main Form */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Formulaire d'extraction</CardTitle>
                <div className="flex items-center gap-2">
                  {!showAddField ? (
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 gap-1 bg-transparent"
                      onClick={() => setShowAddField(true)}
                    >
                      <Plus className="h-3 w-3" />
                      Ajouter champ
                    </Button>


                  ) : (
                    <div className="flex items-center gap-2">
                      <Input
                        placeholder="Nom du champ"
                        value={newFieldLabel}
                        onChange={(e) => setNewFieldLabel(e.target.value)}
                        className="h-8 w-32 bg-transparent"
                        onKeyDown={(e) => e.key === "Enter" && addCustomField()}
                      />
                      <Button size="sm" className="h-8" onClick={addCustomField}>
                        <Check className="h-3 w-3" />
                      </Button>
                      <Button size="sm" variant="ghost" className="h-8" onClick={() => setShowAddField(false)}>
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              {/* Grid Layout - 2 colonnes */}
              <div className="grid grid-cols-2 gap-4">
                {/* Ligne 1: Date | Numéro de facture */}
                {renderFieldCard(fields.find(f => f.key === 'invoiceDate') || fields[0])}
                {renderFieldCard(fields.find(f => f.key === 'invoiceNumber') || fields[1])}

                {/* Ligne 2: Fournisseur | Compte fournisseur */}
                {renderFieldCard(fields.find(f => f.key === 'supplier') || fields[2])}
                {renderAccountFieldCard('accountSupplier', 'Compte fournisseur', 'supplierAccount')}

                {/* Ligne 3: Montant HT | Compte HT */}
                {renderFieldCard(fields.find(f => f.key === 'amountHT') || fields[3])}
                {renderAccountFieldCard('accountHT', 'Compte HT', 'defaultChargeAccount')}

                {/* Ligne 4: % TVA | Compte TVA */}
                {renderFieldCard(fields.find(f => f.key === 'tva') || fields[4])}
                {renderAccountFieldCard('accountTVA', 'Compte TVA', 'tvaAccount')}

                {/* Ligne 5: Montant TTC | Identifiant Fiscal */}
                {renderFieldCard(fields.find(f => f.key === 'amountTTC') || fields[5])}
                {renderFieldCard(fields.find(f => f.key === 'ifNumber') || fields[6])}

                {/* Ligne 6: ICE | RC */}
                {renderFieldCard(fields.find(f => f.key === 'ice') || fields[7])}
                {renderFieldCard(fields.find(f => f.key === 'rcNumber') || fields[8])}
              </div>

              {/* Custom Fields - En dessous de la grille */}
              {customFields.length > 0 && (
                <div className="mt-6 space-y-3">
                  <h3 className="text-sm font-medium text-muted-foreground">Champs personnalisés</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {customFields.map((field) => renderFieldCard(field, true))}
                  </div>
                </div>
              )}

            </CardContent>
          </Card>

          {/* OCR Text */}
          <Collapsible open={showOcrText} onOpenChange={setShowOcrText}>
            <Card>
              <CollapsibleTrigger asChild>
                <CardHeader className="cursor-pointer hover:bg-muted/50 transition-colors pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">Texte OCR extrait</CardTitle>
                    <ChevronDown className={`h-4 w-4 transition-transform ${showOcrText ? "rotate-180" : ""}`} />
                  </div>
                </CardHeader>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <CardContent>
                  <Textarea
                    value={extractedText}
                    onChange={(e) => setExtractedText(e.target.value)}
                    className="min-h-[200px] font-mono text-xs bg-muted/50"
                    placeholder="Le texte extrait apparaitra ici..."
                  />
                </CardContent>
              </CollapsibleContent>
            </Card>
          </Collapsible>

          {/* Nouveau: Selection de Signature pour Template Automatique */}
          {canCreateTemplate && !templateDetected && (
            <Card className="border-primary/20 bg-primary/5">
              <CardHeader className="py-3 px-4">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-primary" />
                  Créer un Template
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 pb-4 px-4">
                <p className="text-[11px] text-muted-foreground leading-tight">
                  Un ICE ou IF a été détecté. Choisissez la signature pour créer le template automatiquement lors de l'enregistrement.
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {fields.find(f => f.key === "ice")?.value ? (
                    <Button
                      variant={selectedSignature === "ice" ? "default" : "outline"}
                      size="sm"
                      className="text-[10px] h-8 gap-1 p-1"
                      onClick={() => setSelectedSignature(selectedSignature === "ice" ? null : "ice")}
                    >
                      ICE: {String(fields.find(f => f.key === "ice")?.value).slice(-4)}
                    </Button>
                  ) : null}
                  {fields.find(f => f.key === "ifNumber")?.value ? (
                    <Button
                      variant={selectedSignature === "ifNumber" ? "default" : "outline"}
                      size="sm"
                      className="text-[10px] h-8 gap-1 p-1"
                      onClick={() => setSelectedSignature(selectedSignature === "ifNumber" ? null : "ifNumber")}
                    >
                      IF: {String(fields.find(f => f.key === "ifNumber")?.value).slice(-4)}
                    </Button>
                  ) : null}
                </div>
                {selectedSignature && (
                  <p className="text-[10px] text-primary font-medium text-center bg-primary/10 py-1 rounded">
                    ✓ Template auto avec {selectedSignature === "ifNumber" ? "IF" : "ICE"}
                  </p>
                )}
                <div className="pt-2 border-t border-primary/10">
                  <Button
                    variant="link"
                    size="sm"
                    className="h-auto p-0 text-[11px] text-primary w-full justify-center gap-1"
                    onClick={() => setIsCreatingTemplate(true)}
                  >
                    <Sparkles className="h-3 w-3" />
                    Configuration avancée (Wizard)
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3">
            {/* BOUTON ENREGISTRER (toujours disponible sauf si validé) */}
            <Button
              variant="outline"
              className="flex-1 gap-2 bg-transparent"
              onClick={handleSave}
              disabled={isSaving || isValidated}
            >
              {isSaving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Sauvegarde...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  Enregistrer
                </>
              )}
            </Button>

            {/*  BOUTON VALIDER (disponible uniquement si READY_TO_VALIDATE) */}
            <Button
              className="flex-1 gap-2"
              onClick={handleValidate}
              disabled={
                isValidating ||
                isValidated ||
                status === "pending" ||
                status === "processing" ||
                status === "treated" // Pas encore enregistré
              }
            >
              {isValidating ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Validation...
                </>
              ) : isValidated ? (
                <>
                  <CheckCircle className="h-4 w-4" />
                  Validée
                </>
              ) : status === "ready_to_validate" ? (
                <>
                  <CheckCircle className="h-4 w-4" />
                  Valider
                </>
              ) : (
                <>
                  <CheckCircle className="h-4 w-4" />
                  Enregistrer d'abord
                </>
              )}
            </Button>
          </div>
          {status === "treated" && (
            <p className="text-sm text-muted-foreground text-center">
              Enregistrez les données avant de pouvoir valider
            </p>
          )}

          {status === "ready_to_validate" && !isValidated && (
            <p className="text-sm text-emerald-600 text-center">
              Facture prête à être validée
            </p>
          )}
        </div >
      </div >

      {/* Wizard Création Template */}
      <DynamicTemplateWizard
        open={isCreatingTemplate}
        onOpenChange={setIsCreatingTemplate}
        invoice={invoice}
        ice={fields.find(f => f.key === "ice")?.value as string}
        ifNumber={fields.find(f => f.key === "if")?.value as string}
        supplier={fields.find(f => f.key === "supplier")?.value as string}
        onSuccess={(templateId) => {
          setTemplateDetected(true)
          handleOcrExtract(templateId)
          toast.success("Template créé et appliqué !")
        }}
      />
    </div >
  )
}